# 🥛 Dairy-X E-Commerce Website

## Project Information
- **Project Title**: Dairy Product E-Commerce Website
- **Student Name**: Krishna Vinayak Solanke
- **Course**: FYMCA (First Year Master of Computer Applications)
- **Roll Number**: 202501109043
- **Institution**: Jawaharlal Nehru Engineering College, MGM University, Aurangabad
- **Year**: July-2025

---

## 📋 Table of Contents
1. [Introduction](#introduction)
2. [Features](#features)
3. [Technology Stack](#technology-stack)
4. [Installation Guide](#installation-guide)
5. [Database Setup](#database-setup)
6. [Project Structure](#project-structure)
7. [Usage](#usage)
8. [Screenshots](#screenshots)

---

## 🎯 Introduction
Dairy-X is a web-based online dairy product store where users can browse, search, and purchase dairy products like milk, cheese, butter, and sweets. It replicates the core features of major e-commerce platforms like Flipkart/Amazon but at a small scale, focusing exclusively on dairy products.

---

## ✨ Features

### User Features
- ✅ User Registration & Login System
- ✅ Browse Products by Categories (Sweet, Milk Products, Cream)
- ✅ Product Display with Images, Ratings & Prices
- ✅ Add to Cart Functionality
- ✅ Shopping Cart Management
- ✅ Cash on Delivery Option
- ✅ Contact Form
- ✅ Responsive Design

### Admin Features (To be implemented with PHP)
- 📦 Product Management (Add/Edit/Delete)
- 👥 User Management
- 📊 Order Management
- 📈 Dashboard with Analytics

---

## 🛠 Technology Stack

### Frontend
- **HTML5** - Structure
- **CSS3** - Styling with custom animations
- **JavaScript (ES6)** - Interactivity and cart functionality
- **Font Awesome** - Icons

### Backend (Ready for implementation)
- **PHP** - Server-side scripting
- **MySQL** - Database management

### Development Tools
- **XAMPP** - Local development server
- **VS Code** - Code editor

---

## 📥 Installation Guide

### Prerequisites
- XAMPP (or WAMP/LAMP)
- Modern web browser (Chrome, Firefox, Edge)
- Text editor (VS Code recommended)

### Steps

1. **Install XAMPP**
   - Download from [https://www.apachefriends.org/](https://www.apachefriends.org/)
   - Install and start Apache and MySQL services

2. **Clone/Download Project**
   ```bash
   # Navigate to XAMPP htdocs folder
   cd C:\xampp\htdocs
   
   # Create project folder
   mkdir dairy-x
   
   # Copy all project files to this folder
   ```

3. **Access the Website**
   - Open browser and navigate to: `http://localhost/dairy-x/Dairy.html`

---

## 🗄 Database Setup

### Step 1: Create Database
1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Click "New" to create a new database
3. Name it: `dairy_ecommerce`
4. Click "Create"

### Step 2: Import Database Schema
1. Select the `dairy_ecommerce` database
2. Click "Import" tab
3. Choose the `database.sql` file from the project folder
4. Click "Go" to execute

### Database Tables
- **users** - Store user information
- **products** - Store product details
- **orders** - Store order information
- **order_items** - Store individual order items
- **cart** - Store cart items
- **admin** - Store admin credentials

---

## 📁 Project Structure

```
dairy-x/
│
├── Dairy.html              # Main homepage
├── login.html              # User login page
├── signup.html             # User registration page
├── style.css               # Main stylesheet
├── script.js               # JavaScript functionality
├── config.php              # Database configuration
├── database.sql            # Database schema & sample data
├── README.md               # Project documentation
│
├── image/                  # Header images
├── Sweet/                  # Sweet product images
└── Milk/                   # Milk product images
```

---

## 🚀 Usage

### For Users
1. **Browse Products**
   - Visit homepage to see all products
   - Navigate using dropdown menu (Sweet, Milk, Cream products)

2. **Add to Cart**
   - Click "🛒 Add to Cart" button on any product
   - View cart count in navigation bar

3. **Register/Login**
   - Click "LOG IN" in navigation
   - New users: Click "Sign Up" to create account
   - Existing users: Enter credentials to login

4. **Contact**
   - Scroll to Contact section
   - Fill out the contact form
   - Submit your inquiry

### For Developers
1. **Modify Products**
   - Edit `database.sql` to add/modify products
   - Update product images in respective folders

2. **Customize Styling**
   - Edit `style.css` for visual changes
   - Modify color scheme, fonts, layouts

3. **Add Features**
   - Extend `script.js` for new JavaScript functionality
   - Create PHP files for backend processing

---

## 🎨 Features Implemented

### ✅ Current Features
- [x] Responsive gallery slider
- [x] Product catalog with categories
- [x] Star ratings display
- [x] Add to cart functionality
- [x] Cart count tracker
- [x] Login/Signup forms
- [x] Contact section with form
- [x] Footer with social links
- [x] Smooth scrolling navigation
- [x] LocalStorage cart persistence

### 🔜 Upcoming Features
- [ ] PHP backend integration
- [ ] Database connectivity
- [ ] Payment gateway (Razorpay/PayPal)
- [ ] Order tracking system
- [ ] Admin dashboard
- [ ] Email notifications
- [ ] Product search functionality
- [ ] User profile management
- [ ] Order history

---

## 🐛 Known Issues & Fixes

### Issues Fixed in Latest Version:
1. ✅ Missing `script.js` file - **FIXED**
2. ✅ Broken navigation links - **FIXED**
3. ✅ Incorrect login link path - **FIXED**
4. ✅ Gallery image overflow - **FIXED**
5. ✅ Duplicate product names - **FIXED**
6. ✅ Missing contact section - **FIXED**
7. ✅ No footer - **FIXED**

---

## 📝 Database Schema

### Users Table
```sql
- id (Primary Key)
- name
- email (Unique)
- phone
- password
- address
- created_at
- updated_at
```

### Products Table
```sql
- id (Primary Key)
- name
- description
- price
- category
- image
- stock
- rating
- created_at
- updated_at
```

### Orders Table
```sql
- id (Primary Key)
- user_id (Foreign Key)
- total_amount
- payment_method
- delivery_address
- status
- order_date
```

---

## 🎓 Academic Purpose

This project is developed as part of the FYMCA curriculum to demonstrate:
- Full-stack web development skills
- E-commerce website architecture
- Database design and management
- Frontend and backend integration
- User authentication systems
- Shopping cart implementation

---

## 📚 References

1. **W3Schools** - HTML, CSS, JavaScript tutorials
   - [https://www.w3schools.com/](https://www.w3schools.com/)

2. **PHP Documentation**
   - [https://www.php.net/docs.php](https://www.php.net/docs.php)

3. **MySQL Documentation**
   - [https://dev.mysql.com/doc/](https://dev.mysql.com/doc/)

4. **E-commerce Platforms** (for inspiration)
   - Flipkart
   - Amazon
   - Zomato

---

## 👨‍💻 Developer

**Krishna Vinayak Solanke**
- Course: FYMCA
- Roll Number: 202501109043
- Institution: Jawaharlal Nehru Engineering College, MGM University
- Email: krishnasolanke@example.com

---

## 📄 License

This project is developed for academic purposes as part of FYMCA curriculum.

---

## 🙏 Acknowledgments

- Jawaharlal Nehru Engineering College
- MGM University, Aurangabad
- Project Guide and Faculty Members
- All reference websites and documentation sources

---

## 📞 Support

For any queries or support:
- Email: info@dairy-x.com
- Phone: +91 1234567890

---

**Last Updated**: October 14, 2025
**Version**: 1.0
