-- ============================================
-- Create Admin User for Dairy-X E-Commerce
-- ============================================
-- This script creates the admin user with credentials:
-- Email/Username: admin@dairy-x.com OR admin
-- Password: admin123
-- ============================================

USE dairy_ecommerce;

-- First, check if admin already exists and delete it
DELETE FROM users WHERE email = 'admin@dairy-x.com' AND role = 'admin';

-- Create admin user with properly hashed password
-- Password: admin123 (hashed with bcrypt)
INSERT INTO users (fullname, email, phone, password_hash, role, created_at) 
VALUES (
    'Admin User',
    'admin@dairy-x.com',
    '+91 9000000000',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'admin',
    NOW()
);

-- Verify admin user was created
SELECT 
    id,
    fullname,
    email,
    phone,
    role,
    created_at,
    'Password: admin123' as password_info
FROM users 
WHERE email = 'admin@dairy-x.com' AND role = 'admin';

-- Show all admin users
SELECT 
    'Total Admin Users:' as info,
    COUNT(*) as count
FROM users 
WHERE role = 'admin';

-- ============================================
-- SUCCESS! Your admin credentials are:
-- Email/Username: admin@dairy-x.com OR admin
-- Password: admin123
-- ============================================
