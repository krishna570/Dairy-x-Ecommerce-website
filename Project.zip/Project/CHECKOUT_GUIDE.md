# 🛒 Checkout & Payment Guide - Dairy-X

## Overview
The Dairy-X checkout system provides a comprehensive buying experience with multiple payment options including Cash on Delivery, PhonePe UPI, and QR Code payments.

---

## 📋 Features

### 1. **Delivery Information Form**
- Full Name (Required)
- Phone Number (Required)
- Email Address (Required)
- Delivery Address (Required)
- City & Pin Code (Required)
- State (Required)
- Landmark (Optional)

### 2. **Payment Options**

#### 💵 Cash on Delivery (COD)
- **How it works**: Pay in cash when you receive your order
- **Benefits**:
  - No advance payment required
  - Inspect products before payment
  - Safe and convenient
- **Status**: Order confirmed immediately

#### 📱 PhonePe UPI Payment
- **How it works**: Pay instantly via PhonePe app
- **UPI ID**: `dairyx@ybl`
- **Steps**:
  1. Open PhonePe app
  2. Enter UPI ID: `dairyx@ybl`
  3. Enter the order amount
  4. Complete payment
  5. Copy transaction ID
  6. Enter transaction ID in checkout form
  7. Upload payment screenshot (optional)
- **Status**: Payment pending verification

#### 📲 QR Code Payment
- **How it works**: Scan QR code with any UPI app
- **Supported Apps**: PhonePe, Google Pay, Paytm, etc.
- **Steps**:
  1. Scan the displayed QR code
  2. Verify amount in your UPI app
  3. Complete payment
  4. Copy transaction/reference ID
  5. Enter transaction ID in checkout form
  6. Upload payment screenshot (optional)
- **Status**: Payment pending verification

---

## 🔄 Order Flow

### For Cash on Delivery:
```
Add to Cart → Checkout → Fill Details → Select COD → Place Order → Order Confirmed
```

### For Online Payment (PhonePe/QR):
```
Add to Cart → Checkout → Fill Details → Select Payment → Make Payment → 
Enter Transaction ID → Upload Screenshot → Place Order → Payment Pending
```

---

## 💰 Pricing Structure

| Item | Description | Amount |
|------|-------------|--------|
| Subtotal | Total price of all items | Calculated |
| Delivery Fee | Standard delivery charge | $5.00 |
| Tax | 5% of subtotal | Calculated |
| **Total** | **Final payable amount** | **Calculated** |

---

## 🚀 How to Use

### Step 1: Add Products to Cart
- Browse products on the homepage
- Click "🛒 Add to Cart" to add items
- Or click "🛍️ Buy Now" for instant checkout

### Step 2: View Shopping Cart
- Click "🛒 Cart" in navigation
- Review your items
- Update quantities or remove items
- Click "Proceed to Checkout"

### Step 3: Fill Delivery Details
- Enter your full name
- Provide valid phone number
- Enter email address
- Fill complete delivery address
- Provide city, state, and pin code
- Add landmark for easy location (optional)

### Step 4: Select Payment Method
- Choose from three options:
  - **Cash on Delivery** (Default)
  - **PhonePe UPI**
  - **QR Code Payment**

### Step 5: Complete Payment (For Online Payments)
- Follow payment instructions
- Make payment via selected method
- Copy transaction/reference ID
- Enter transaction ID in the form
- Upload payment screenshot (optional but recommended)

### Step 6: Place Order
- Review order summary
- Verify delivery details
- Click "Place Order" button
- Receive order confirmation

---

## 📱 Payment Method Details

### Cash on Delivery
- **Processing Time**: Immediate
- **Delivery**: 2-3 business days
- **Payment**: At doorstep
- **Inspection**: Allowed before payment
- **Refund**: Easy returns

### PhonePe UPI
- **Processing Time**: Instant
- **Verification**: 1-2 hours
- **Confirmation**: Via email/SMS
- **UPI ID**: dairyx@ybl
- **Transaction ID**: Mandatory

### QR Code Payment
- **Processing Time**: Instant
- **Verification**: 1-2 hours
- **Supported Apps**: All UPI apps
- **Scan & Pay**: Yes
- **Transaction ID**: Mandatory

---

## 🔒 Security Features

- ✅ Secure form validation
- ✅ Encrypted data transmission
- ✅ Transaction ID verification
- ✅ Payment screenshot backup
- ✅ Order confirmation email
- ✅ No card details stored
- ✅ Safe and trusted payment gateways

---

## 📊 Order Management

### Order Confirmation
After placing an order, you receive:
- Unique Order ID (e.g., ORD1234567890)
- Order summary with item details
- Total amount paid/to be paid
- Payment method confirmation
- Estimated delivery date

### Order History
- All orders saved in browser (localStorage)
- View past orders anytime
- Track order status
- Download order receipt

---

## 🛠 Technical Details

### Frontend
- Pure HTML5, CSS3, JavaScript
- No external dependencies (except Font Awesome)
- Responsive design for all devices
- Real-time form validation

### Data Storage
- Cart data: Browser localStorage
- Order history: Browser localStorage
- User data: localStorage (to be migrated to backend)

### Payment Integration
- PhonePe UPI: Manual verification
- QR Code: Generated via API
- Transaction tracking system

---

## 🐛 Troubleshooting

### Common Issues

**Q: Cart is empty when I go to checkout**
- A: Make sure JavaScript is enabled
- A: Check if localStorage is cleared
- A: Add items to cart first

**Q: Payment not verified after entering transaction ID**
- A: Wait 1-2 hours for verification
- A: Upload payment screenshot
- A: Contact support with order ID

**Q: Order not placed after clicking button**
- A: Fill all required fields
- A: Check internet connection
- A: Try refreshing the page

**Q: QR code not displaying**
- A: Check internet connection
- A: Refresh the page
- A: Try different browser

---

## 📞 Support

### Contact Information
- **Email**: support@dairy-x.com
- **Phone**: +91 1234567890
- **Working Hours**: Mon-Sat, 8:00 AM - 8:00 PM

### Payment Issues
- **Email**: payments@dairy-x.com
- **Response Time**: Within 2 hours

---

## 🎯 Best Practices

### For Users
1. Always keep transaction ID handy
2. Take screenshot of successful payment
3. Double-check delivery address
4. Provide correct phone number
5. Use valid email for notifications

### For Smooth Ordering
1. Review cart before checkout
2. Verify all details before placing order
3. Keep phone accessible for delivery calls
4. Be available at delivery address
5. Inspect products upon delivery (COD)

---

## 📈 Future Enhancements

- [ ] Real-time payment gateway integration
- [ ] Automatic payment verification
- [ ] Email notifications
- [ ] SMS alerts
- [ ] Order tracking in real-time
- [ ] Multiple delivery addresses
- [ ] Saved payment methods
- [ ] Wallet integration
- [ ] Discount coupons
- [ ] Loyalty points

---

## 🔐 Privacy & Data

### What We Collect
- Name, email, phone number
- Delivery address
- Order history
- Payment transaction IDs

### How We Use It
- Process and deliver orders
- Send order confirmations
- Verify payments
- Improve user experience

### Data Security
- No sensitive data stored
- Secure form submission
- No card details collected
- Browser-based storage (temporary)

---

## 📝 Notes

1. **Login Required**: You must be logged in to checkout
2. **Cart Persistence**: Cart items saved across sessions
3. **Order Limit**: No minimum order value
4. **Delivery Areas**: Currently serving all India
5. **Payment Confirmation**: Check email for confirmation

---

## 🎓 For Developers

### File Structure
```
checkout.html    - Main checkout page
script.js        - Buy Now functionality
cart.html        - Modified for checkout redirect
```

### Key Functions
- `loadCart()` - Load cart items
- `displayOrderSummary()` - Show order summary
- `selectPayment()` - Handle payment selection
- `placeOrder()` - Process order placement
- `loadUserData()` - Pre-fill user information

### LocalStorage Keys
- `dairyCart` - Shopping cart data
- `orderHistory` - All placed orders
- `isLoggedIn` - User login status
- `userEmail` - User email address

---

**Last Updated**: October 14, 2025  
**Version**: 2.1  
**Feature**: Checkout & Payment System
