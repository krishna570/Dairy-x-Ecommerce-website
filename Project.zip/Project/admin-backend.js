// Admin Dashboard Backend Integration Script

const API_BASE = 'api';

// Check admin authentication
checkAdminAuth();

async function checkAdminAuth() {
    try {
        const response = await fetch(`${API_BASE}/auth.php?action=check`);
        const data = await response.json();
        
        if (!data.success || !data.authenticated || data.user.role !== 'admin') {
            alert('Unauthorized access! Admin login required.');
            window.location.href = 'login.html';
            return;
        }
        
        // Load dashboard data
        loadDashboardData();
    } catch (error) {
        console.error('Auth check failed:', error);
        alert('Authentication error');
        window.location.href = 'login.html';
    }
}

// Switch between tabs
function switchTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(tabName + 'Tab').classList.add('active');
    event.target.classList.add('active');
}

// Load dashboard data
async function loadDashboardData() {
    await loadStatistics();
    await loadUsers();
    await loadCarts();
    await loadOrders();
}

// Load statistics
async function loadStatistics() {
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=statistics`);
        const data = await response.json();
        
        if (data.success) {
            const stats = data.statistics;
            document.getElementById('totalUsers').textContent = stats.total_users;
            document.getElementById('totalOrders').textContent = stats.total_orders;
            document.getElementById('totalRevenue').textContent = '₹' + stats.total_revenue.toFixed(2);
            
            if (document.querySelector('.stat-details h3:last-of-type')) {
                document.querySelector('.stat-details h3:last-of-type').textContent = stats.total_products;
            }
        }
    } catch (error) {
        console.error('Failed to load statistics:', error);
    }
}

// Load all users
async function loadUsers() {
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=users`);
        const data = await response.json();
        
        const usersBody = document.getElementById('usersTableBody');
        
        if (data.success && data.users.length > 0) {
            usersBody.innerHTML = data.users.map((user, index) => `
                <tr>
                    <td>${index + 1}</td>
                    <td>${user.fullname || 'N/A'}</td>
                    <td>${user.email}</td>
                    <td>${user.phone || 'N/A'}</td>
                    <td>${new Date(user.created_at).toLocaleDateString()}</td>
                    <td><span class="badge active">Active</span></td>
                    <td>
                        <button class="action-btn" onclick="viewUserDetails('${user.email}')">
                            <i class="fas fa-eye"></i> View
                        </button>
                    </td>
                </tr>
            `).join('');
        } else {
            usersBody.innerHTML = `
                <tr>
                    <td colspan="7">
                        <div class="empty-state">
                            <i class="fas fa-users"></i>
                            <p>No users registered yet</p>
                        </div>
                    </td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Failed to load users:', error);
    }
}

// Load all user carts
async function loadCarts() {
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=carts`);
        const data = await response.json();
        
        const cartsBody = document.getElementById('cartsTableBody');
        
        if (data.success && data.carts.length > 0) {
            cartsBody.innerHTML = data.carts.map(item => `
                <tr>
                    <td>${item.user_email}</td>
                    <td>${item.product_name}</td>
                    <td>${item.quantity}</td>
                    <td>₹${item.product_price.toFixed(2)}</td>
                    <td>₹${item.total_price.toFixed(2)}</td>
                    <td>${new Date(item.added_at).toLocaleDateString()}</td>
                </tr>
            `).join('');
        } else {
            cartsBody.innerHTML = `
                <tr>
                    <td colspan="6">
                        <div class="empty-state">
                            <i class="fas fa-shopping-cart"></i>
                            <p>No active carts</p>
                        </div>
                    </td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Failed to load carts:', error);
    }
}

// Load order history
async function loadOrders() {
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=orders`);
        const data = await response.json();
        
        const ordersBody = document.getElementById('ordersTableBody');
        
        if (data.success && data.orders.length > 0) {
            ordersBody.innerHTML = data.orders.map((order, index) => {
                const productNames = order.items.map(i => i.name).join(', ');
                return `
                    <tr>
                        <td>#ORD${String(order.id).padStart(4, '0')}</td>
                        <td>${order.user_email}</td>
                        <td>${productNames}</td>
                        <td>₹${order.total_amount.toFixed(2)}</td>
                        <td>${new Date(order.order_date).toLocaleString()}</td>
                        <td><span class="badge ${order.status.toLowerCase()}">${order.status}</span></td>
                        <td>
                            <button class="action-btn" onclick="viewOrderDetails(${order.id})">
                                <i class="fas fa-eye"></i> View
                            </button>
                            <select onchange="updateOrderStatus(${order.id}, this.value)" style="margin-top: 5px; padding: 4px;">
                                <option value="">Change Status</option>
                                <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pending</option>
                                <option value="processing" ${order.status === 'processing' ? 'selected' : ''}>Processing</option>
                                <option value="completed" ${order.status === 'completed' ? 'selected' : ''}>Completed</option>
                                <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                            </select>
                        </td>
                    </tr>
                `;
            }).join('');
        } else {
            ordersBody.innerHTML = `
                <tr>
                    <td colspan="7">
                        <div class="empty-state">
                            <i class="fas fa-box-open"></i>
                            <p>No orders placed yet</p>
                        </div>
                    </td>
                </tr>
            `;
        }
    } catch (error) {
        console.error('Failed to load orders:', error);
    }
}

// View user details
function viewUserDetails(email) {
    alert(`User Details:\nEmail: ${email}\n\nIn production, this would show complete user profile.`);
}

// View order details
async function viewOrderDetails(orderId) {
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=orders`);
        const data = await response.json();
        
        if (data.success) {
            const order = data.orders.find(o => o.id === orderId);
            
            if (order) {
                const details = `
Order ID: #ORD${String(order.id).padStart(4, '0')}
User: ${order.user_email}
Name: ${order.fullname}
Phone: ${order.phone}
Address: ${order.address}, ${order.city}, ${order.state} - ${order.pincode}
Date: ${new Date(order.order_date).toLocaleString()}
Status: ${order.status}
Payment: ${order.payment_method} (${order.payment_status})
${order.transaction_id ? 'Transaction ID: ' + order.transaction_id : ''}

Items:
${order.items.map(item => `- ${item.name} x${item.quantity} = ₹${(item.price * item.quantity).toFixed(2)}`).join('\n')}

Subtotal: ₹${(order.total_amount - order.delivery_fee - order.tax_amount).toFixed(2)}
Delivery Fee: ₹${order.delivery_fee.toFixed(2)}
Tax: ₹${order.tax_amount.toFixed(2)}
Total Amount: ₹${order.total_amount.toFixed(2)}
                `.trim();
                
                alert(details);
            }
        }
    } catch (error) {
        console.error('Failed to load order details:', error);
    }
}

// Update order status
async function updateOrderStatus(orderId, status) {
    if (!status) return;
    
    try {
        const response = await fetch(`${API_BASE}/admin.php?action=update_order_status`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                order_id: orderId,
                status: status
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Order status updated successfully');
            await loadOrders();
        } else {
            alert('Failed to update order status: ' + data.message);
        }
    } catch (error) {
        console.error('Failed to update order status:', error);
        alert('Failed to update order status');
    }
}

// Logout function
async function logout() {
    if (confirm('Are you sure you want to logout?')) {
        try {
            const response = await fetch(`${API_BASE}/auth.php?action=logout`, {
                method: 'POST'
            });
            
            const data = await response.json();
            
            if (data.success) {
                alert('Logged out successfully!');
                window.location.href = 'login.html';
            }
        } catch (error) {
            console.error('Logout failed:', error);
            alert('Logout failed');
        }
    }
}

// Auto-refresh every 30 seconds
setInterval(loadDashboardData, 30000);
