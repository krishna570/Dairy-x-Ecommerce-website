# 🚀 Dairy-X Quick Reference Card

## 📋 Essential Information

### 🔗 URLs
- **Main Site**: http://localhost/Project/index.php
- **Login**: http://localhost/Project/login.html
- **Signup**: http://localhost/Project/signup.html
- **Cart**: http://localhost/Project/cart.html
- **Admin**: http://localhost/Project/admin-dashboard.html
- **phpMyAdmin**: http://localhost/phpmyadmin

### 🔐 Default Credentials

**Admin:**
- Username: `admin@dairy-x.com` or `admin`
- Password: `admin123`

**Demo User:**
- Email: `demo@dairy-x.com`
- Password: `password`

### 💾 Database Info
- Database Name: `dairy_ecommerce`
- Host: `localhost`
- User: `root`
- Password: ` ` (empty)

---

## 🎯 Quick Start (3 Steps)

```bash
# 1. Start XAMPP
Start Apache + MySQL

# 2. Import Database
phpMyAdmin → Import → database.sql

# 3. Access App
http://localhost/Project/index.php
```

---

## 📁 Project Structure

```
Project/
├── api/                   # Backend APIs
│   ├── auth.php          # Login/Signup
│   ├── cart.php          # Cart operations
│   ├── orders.php        # Order management
│   └── admin.php         # Admin dashboard
│
├── *.js                   # Frontend integration
├── *.html                 # Pages
├── index.php             # Main page
├── config.php            # DB config
└── database.sql          # Schema
```

---

## 🔄 API Quick Reference

### Auth
```
POST /api/auth.php?action=register
POST /api/auth.php?action=login
POST /api/auth.php?action=admin_login
POST /api/auth.php?action=logout
GET  /api/auth.php?action=check
```

### Cart (Login Required)
```
GET  /api/cart.php?action=get
POST /api/cart.php?action=add
POST /api/cart.php?action=update
POST /api/cart.php?action=delete
POST /api/cart.php?action=clear
```

### Orders (Login Required)
```
POST /api/orders.php?action=place
GET  /api/orders.php?action=get
GET  /api/orders.php?action=details&order_id=X
```

### Admin (Admin Only)
```
GET  /api/admin.php?action=users
GET  /api/admin.php?action=carts
GET  /api/admin.php?action=orders
GET  /api/admin.php?action=statistics
POST /api/admin.php?action=update_order_status
```

---

## 🗄️ Database Tables

```sql
categories       → Sweet, Milk, Cream
products         → 21 sample products
users            → Customers & admins
cart             → Shopping carts
orders           → Order details
order_items      → Order products
```

---

## 🧪 Quick Test

```sql
-- View all tables
SHOW TABLES;

-- Check products
SELECT * FROM products LIMIT 5;

-- Check users
SELECT * FROM users;

-- Check carts
SELECT * FROM cart;

-- Check orders
SELECT * FROM orders;
```

---

## ⚡ Features Checklist

### User Features
✅ Register & Login
✅ Browse products
✅ Add to cart (persistent)
✅ Update cart
✅ Checkout
✅ Multiple payments (COD, UPI, QR)
✅ Order history

### Admin Features
✅ Admin login
✅ View all users
✅ Monitor carts
✅ Manage orders
✅ Update order status
✅ Revenue tracking

---

## 🐛 Troubleshooting

**Can't login?**
→ Check database imported, verify credentials

**Cart not working?**
→ Ensure logged in, check cart table exists

**Database error?**
→ Verify MySQL running, check config.php

**Products not showing?**
→ Import database.sql again

---

## 📞 Need Help?

1. Check browser console (F12)
2. Check PHP errors in `xampp/apache/logs/error.log`
3. Verify database in phpMyAdmin
4. Review BACKEND_SETUP_GUIDE.md

---

## ✨ You're All Set!

**Your full-stack e-commerce platform is ready!**

🎯 Test user flow → 🛒 Add to cart → ✅ Place order → 👨‍💼 Check admin panel

**Happy Selling! 🚀**
