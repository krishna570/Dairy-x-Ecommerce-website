# 🚨 ADMIN LOGIN NOT WORKING - COMPLETE FIX GUIDE

## You're trying: admin / admin123 but getting "Unauthorized" error

---

## 🔍 STEP-BY-STEP DIAGNOSIS & FIX

### **STEP 1: Check if MySQL is Running** ✅

1. Open XAMPP Control Panel
2. Look for MySQL - should show **green "Running"**
3. If not running, click "Start" button

---

### **STEP 2: Run Auto-Fix Script** ⚡ (EASIEST METHOD)

I created an automatic checker/fixer for you!

#### In your browser, go to:
```
http://localhost/Project/check_admin.php
```

This script will:
- ✅ Check if admin user exists
- ✅ Test if password 'admin123' works
- ✅ Automatically fix the password if needed
- ✅ Show you exactly what to do next

**Just open that URL and it will fix everything automatically!**

---

### **STEP 3: Manual Fix (If auto-fix doesn't work)**

#### Option A: Using phpMyAdmin (Recommended)

1. **Open phpMyAdmin**
   - URL: http://localhost/phpmyadmin
   
2. **Select Database**
   - Click `dairy_ecommerce` in left sidebar
   
3. **Click SQL Tab**
   - It's at the top of the page
   
4. **Copy & Paste This Query**
   ```sql
   -- Fix admin password
   UPDATE users 
   SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
   WHERE email = 'admin@dairy-x.com' AND role = 'admin';
   
   -- Verify it worked
   SELECT email, role FROM users WHERE role = 'admin';
   ```
   
5. **Click "Go" Button**
   - Should see: "1 row affected" ✅
   - Then shows admin user details

#### Option B: Check if Admin User Exists

If you see "0 rows affected", admin user doesn't exist! Run this:

```sql
-- Create admin user
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES (
  'Admin User',
  'admin@dairy-x.com',
  '+91 9000000000',
  '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
  'admin'
);
```

---

### **STEP 4: Clear Browser Cache** 🧹

Sometimes old session data causes issues:

1. Press `Ctrl + Shift + Delete` (Windows)
2. Select "Cookies and other site data"
3. Click "Clear data"

**OR** just try **Incognito/Private mode**:
- Chrome: `Ctrl + Shift + N`
- Edge: `Ctrl + Shift + P`
- Firefox: `Ctrl + Shift + P`

---

### **STEP 5: Try Login Again** 🔐

1. **Go to Login Page**
   ```
   http://localhost/Project/login.html
   ```

2. **Click "Admin Login" Tab**
   - Make sure you're on ADMIN LOGIN, not user login!

3. **Enter Credentials**
   - **Username:** Type exactly: `admin`
   - **Password:** Type exactly: `admin123`
   - (Case-sensitive! Use lowercase)

4. **Click "Login as Admin" Button**

5. **Should Redirect To:**
   ```
   http://localhost/Project/admin-dashboard.html
   ```

---

## 🎯 COMMON MISTAKES

### ❌ Mistake 1: Using User Login Instead of Admin Login
**Fix:** Make sure you clicked the "Admin Login" tab, not "User Login"

### ❌ Mistake 2: Wrong URL
**Fix:** Use `login.html` not `index.php` for admin login

### ❌ Mistake 3: Database Not Imported
**Fix:** Import `database.sql` in phpMyAdmin first

### ❌ Mistake 4: Typo in Password
**Fix:** Password is `admin123` (all lowercase, no spaces)

### ❌ Mistake 5: MySQL Not Running
**Fix:** Start MySQL in XAMPP Control Panel

---

## 🧪 VERIFICATION CHECKLIST

Check these before trying to login:

- [ ] XAMPP is running
- [ ] Apache is green/running
- [ ] MySQL is green/running
- [ ] Database `dairy_ecommerce` exists
- [ ] Table `users` exists and has data
- [ ] Ran the UPDATE query or check_admin.php
- [ ] Using correct URL: login.html
- [ ] Clicking "Admin Login" tab
- [ ] Using username: `admin`
- [ ] Using password: `admin123`

---

## 🔍 STILL NOT WORKING? DEBUG IT!

### Check 1: Test Database Connection

Open this in browser:
```
http://localhost/Project/check_admin.php
```

Should show admin user details and password status.

### Check 2: Check Browser Console

1. Press `F12` to open Developer Tools
2. Click "Console" tab
3. Look for red errors
4. Take screenshot and check what it says

### Check 3: Check Network Tab

1. Press `F12`
2. Click "Network" tab
3. Try to login
4. Look for `auth.php` request
5. Click on it and check "Response" tab
6. What does it say?

Common responses:
- `{"success":false,"message":"Admin not found"}` → Admin doesn't exist
- `{"success":false,"message":"Invalid credentials"}` → Password wrong
- `{"success":true}` → Login successful (but redirect failed?)

---

## 📋 EXACT CREDENTIALS (Copy These!)

```
Username: admin
Password: admin123
URL: http://localhost/Project/login.html
```

**Alternative username:**
```
Username: admin@dairy-x.com
Password: admin123
```

---

## 🆘 EMERGENCY RESET

If nothing works, do a complete reset:

### 1. Drop Database
In phpMyAdmin SQL tab:
```sql
DROP DATABASE IF EXISTS dairy_ecommerce;
```

### 2. Re-import
- Click "Import" tab
- Choose file: `c:\xampp\htdocs\Project\database.sql`
- Click "Go"

### 3. Verify Import
```sql
SELECT * FROM users WHERE role = 'admin';
```
Should show admin user.

### 4. Try Login
- Username: `admin`
- Password: `admin123`

---

## 🎓 UNDERSTANDING THE ISSUE

### Why is this happening?

The password `admin123` needs to be **hashed** (encrypted) in the database.

**What you see in database:**
```
$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC
```

**What you type:**
```
admin123
```

PHP checks if they match using `password_verify()`.

If the hash in database is wrong, it won't match even if you type the correct password!

---

## ✅ SUCCESS INDICATORS

You'll know it's working when:

1. ✅ No alert saying "Unauthorized access"
2. ✅ Redirects to `admin-dashboard.html`
3. ✅ See dashboard with statistics cards
4. ✅ Can click tabs: "All Users", "User Carts", "Order History"
5. ✅ Top right shows "ADMIN PANEL" and "Logout"

---

## 📞 QUICK HELP COMMANDS

Copy and paste these in phpMyAdmin SQL tab:

**Check if admin exists:**
```sql
SELECT * FROM users WHERE email = 'admin@dairy-x.com';
```

**See all users:**
```sql
SELECT id, email, role FROM users;
```

**Reset admin password:**
```sql
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'admin@dairy-x.com';
```

**Create admin if missing:**
```sql
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES ('Admin User','admin@dairy-x.com','+91 9000000000',
'$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC','admin');
```

---

## 🎯 MOST LIKELY SOLUTION

**90% of the time, this fixes it:**

1. Open: http://localhost/phpmyadmin
2. Select: `dairy_ecommerce` database
3. Click: SQL tab
4. Paste and run:
   ```sql
   UPDATE users 
   SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
   WHERE email = 'admin@dairy-x.com';
   ```
5. Go to: http://localhost/Project/login.html
6. Click: "Admin Login" tab
7. Enter: `admin` / `admin123`
8. Click: "Login as Admin"
9. ✅ DONE!

---

## 🚀 FASTEST FIX (DO THIS FIRST!)

Open your browser and go to:
```
http://localhost/Project/check_admin.php
```

This will automatically check and fix everything for you!

---

**Need more help? Check your browser console (F12) for error messages!**

🎉 **Your admin login will work after following these steps!**
