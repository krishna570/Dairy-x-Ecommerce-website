# 🏗️ Dairy-X System Architecture

## 📊 System Overview Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER (Browser)                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────────┐ │
│  │ index.php│  │login.html│  │cart.html │  │admin-dashboard │ │
│  │          │  │          │  │          │  │    .html       │ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────────┬───────┘ │
│       │             │              │                 │          │
│       │             │              │                 │          │
│  ┌────▼──────────────▼──────────────▼─────────────────▼──────┐ │
│  │         JavaScript Integration Layer                      │ │
│  │  ┌────────────┐  ┌──────────┐  ┌─────────────────────┐  │ │
│  │  │cart-backend│  │login-    │  │admin-backend.js     │  │ │
│  │  │.js         │  │backend.js│  │checkout-script.js   │  │ │
│  │  └────────────┘  └──────────┘  └─────────────────────┘  │ │
│  └───────────────────────────────────────────────────────────┘ │
│                                                                  │
└───────────────────────────┬──────────────────────────────────────┘
                           │ HTTP/AJAX
                           │ (JSON)
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER (PHP APIs)                  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌────────────┐  ┌──────────┐  ┌──────────┐  ┌────────────┐   │
│  │ auth.php   │  │ cart.php │  │orders.php│  │ admin.php  │   │
│  │            │  │          │  │          │  │            │   │
│  │ • Register │  │ • Get    │  │ • Place  │  │ • Users    │   │
│  │ • Login    │  │ • Add    │  │ • Get    │  │ • Carts    │   │
│  │ • Logout   │  │ • Update │  │ • Details│  │ • Orders   │   │
│  │ • Check    │  │ • Delete │  │          │  │ • Stats    │   │
│  └─────┬──────┘  └─────┬────┘  └────┬─────┘  └──────┬─────┘   │
│        │               │             │               │          │
│        └───────────────┴─────────────┴───────────────┘          │
│                            │                                     │
│                    ┌───────▼────────┐                           │
│                    │   config.php   │                           │
│                    │  DB Connection │                           │
│                    └───────┬────────┘                           │
│                            │                                     │
└────────────────────────────┼─────────────────────────────────────┘
                             │ SQL Queries
                             │ (PDO/MySQLi)
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                    DATA LAYER (MySQL Database)                   │
├─────────────────────────────────────────────────────────────────┤
│                     dairy_ecommerce                              │
│                                                                  │
│  ┌──────────────┐  ┌────────────┐  ┌──────────┐               │
│  │ categories   │  │  products  │  │  users   │               │
│  │ • id         │  │ • id       │  │ • id     │               │
│  │ • name       │  │ • name     │  │ • email  │               │
│  │ • slug       │  │ • price    │  │ • role   │               │
│  └──────┬───────┘  └──────┬─────┘  └────┬─────┘               │
│         │                 │              │                      │
│         │        ┌────────▼──────────────▼──────┐              │
│         │        │         cart                 │              │
│         │        │  • user_id (FK to users)    │              │
│         └───────▶│  • product_id (FK)          │              │
│                  │  • quantity                  │              │
│                  └──────────────────────────────┘              │
│                                                                  │
│  ┌──────────────────────────────────────────┐                  │
│  │              orders                      │                  │
│  │  • id                                    │                  │
│  │  • user_id (FK to users)                │                  │
│  │  • fullname, phone, address             │                  │
│  │  • total_amount, status                 │                  │
│  │  • payment_method, payment_status       │                  │
│  └─────────────────┬────────────────────────┘                  │
│                    │                                             │
│         ┌──────────▼──────────────────────┐                    │
│         │       order_items                │                    │
│         │  • order_id (FK to orders)      │                    │
│         │  • product_id (FK to products)  │                    │
│         │  • quantity, unit_price         │                    │
│         └─────────────────────────────────┘                    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow Diagrams

### 1️⃣ User Registration Flow

```
User fills signup form
         │
         ▼
  signup-backend.js
  collects form data
         │
         ▼
  POST /api/auth.php?action=register
  {fullname, email, phone, password}
         │
         ▼
    auth.php validates
    • Email format
    • Email uniqueness
    • Password length
         │
         ▼
  password_hash(password)
         │
         ▼
  INSERT INTO users
  (fullname, email, phone, password_hash, role='user')
         │
         ▼
  Set PHP session
  $_SESSION['user_id'] = new_id
         │
         ▼
  Return JSON
  {success: true, user: {...}}
         │
         ▼
  Redirect to index.php
```

---

### 2️⃣ Add to Cart Flow

```
User clicks "Add to Cart"
         │
         ▼
  cart-backend.js
  addToCart(name, price, productId)
         │
         ▼
  Check if logged in
  (auth.php?action=check)
         │
         ▼
  POST /api/cart.php?action=add
  {product_id, quantity}
         │
         ▼
    cart.php validates
    • User logged in?
    • Product exists?
         │
         ▼
  INSERT INTO cart
  ON DUPLICATE KEY UPDATE
  quantity = quantity + 1
         │
         ▼
  Return JSON
  {success: true}
         │
         ▼
  Update cart count in UI
  Reload cart from backend
```

---

### 3️⃣ Checkout & Order Flow

```
User fills checkout form
         │
         ▼
  checkout-script.js
  collects form + cart items
         │
         ▼
  POST /api/orders.php?action=place
  {fullname, phone, address, city, items[], payment_method}
         │
         ▼
    orders.php validates
    • All required fields?
    • Items exist?
         │
         ▼
  BEGIN TRANSACTION
         │
         ├─▶ INSERT INTO orders
         │   (user_id, fullname, address, total_amount...)
         │
         ├─▶ For each item:
         │   INSERT INTO order_items
         │   (order_id, product_id, quantity, unit_price)
         │
         ├─▶ DELETE FROM cart
         │   WHERE user_id = current_user
         │
         ▼
  COMMIT TRANSACTION
         │
         ▼
  Return JSON
  {success: true, order_id: 123}
         │
         ▼
  Show success message
  Redirect to index.php
```

---

### 4️⃣ Admin Dashboard Flow

```
Admin opens dashboard
         │
         ▼
  admin-backend.js loads
         │
         ▼
  Check admin authentication
  GET /api/auth.php?action=check
         │
         ▼
  If role !== 'admin'
  → Redirect to login.html
         │
         ▼
  GET /api/admin.php?action=statistics
         │
         ▼
    admin.php executes:
    • SELECT COUNT(*) FROM users
    • SELECT COUNT(*) FROM orders
    • SELECT SUM(total_amount) FROM orders
    • SELECT COUNT(*) FROM products
         │
         ▼
  Return JSON
  {statistics: {total_users, total_orders, total_revenue}}
         │
         ▼
  Update dashboard cards
         │
         ├─▶ GET /api/admin.php?action=users
         │   → Display users table
         │
         ├─▶ GET /api/admin.php?action=carts
         │   → Display active carts
         │
         ├─▶ GET /api/admin.php?action=orders
         │   → Display all orders
         │
         ▼
  Auto-refresh every 30 seconds
```

---

## 🔒 Security Architecture

```
┌─────────────────────────────────────────┐
│         Security Layers                 │
├─────────────────────────────────────────┤
│                                         │
│  1️⃣ Input Validation                   │
│     • Client-side (JavaScript)          │
│     • Server-side (PHP)                 │
│                                         │
│  2️⃣ Authentication                      │
│     • Session-based                     │
│     • Password hashing (bcrypt)         │
│                                         │
│  3️⃣ Authorization                       │
│     • Role checks (user/admin)          │
│     • API endpoint protection           │
│                                         │
│  4️⃣ SQL Injection Prevention            │
│     • Prepared statements               │
│     • Parameter binding                 │
│                                         │
│  5️⃣ XSS Prevention                      │
│     • htmlspecialchars()                │
│     • Output escaping                   │
│                                         │
│  6️⃣ Input Sanitization                  │
│     • sanitize_input() function         │
│     • trim, stripslashes, escape        │
│                                         │
└─────────────────────────────────────────┘
```

---

## 📦 Database Relationships

```
categories (1) ──── (Many) products
                           │
                           │ (Many)
                           │
                    ┌──────┴──────┐
                    │              │
                    │              │
            cart (Many)    order_items (Many)
                │                  │
                │                  │
                └──── (1) orders (1)
                           │
                           │
                        users (1)
                           │
                           │
                    ┌──────┴──────┐
                    │              │
                 cart (Many)   orders (Many)
```

**Relationships:**
- 1 Category → Many Products
- 1 User → Many Cart Items
- 1 User → Many Orders
- 1 Product → Many Cart Items
- 1 Product → Many Order Items
- 1 Order → Many Order Items

---

## 🚀 Request-Response Cycle

```
Browser                 PHP API              Database
   │                       │                     │
   │  POST /cart/add       │                     │
   ├──────────────────────▶│                     │
   │                       │                     │
   │                       │  Check session      │
   │                       ├────────────────────▶│
   │                       │                     │
   │                       │  Session valid      │
   │                       │◀────────────────────┤
   │                       │                     │
   │                       │  INSERT cart        │
   │                       ├────────────────────▶│
   │                       │                     │
   │                       │  Row inserted       │
   │                       │◀────────────────────┤
   │                       │                     │
   │  {success: true}      │                     │
   │◀──────────────────────┤                     │
   │                       │                     │
   │  Update UI            │                     │
   │                       │                     │
```

---

## 📊 Technology Stack

```
┌─────────────────────────────────────┐
│         Frontend Layer              │
│  • HTML5                            │
│  • CSS3 (Custom Styles)             │
│  • JavaScript (Vanilla)             │
│  • Font Awesome Icons               │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│         Backend Layer               │
│  • PHP 7.4+                         │
│  • Session Management               │
│  • JSON API Responses               │
│  • MySQLi (Prepared Statements)     │
└─────────────────┬───────────────────┘
                  │
┌─────────────────▼───────────────────┐
│         Database Layer              │
│  • MySQL 5.7+                       │
│  • InnoDB Engine                    │
│  • Foreign Key Constraints          │
│  • Transactions                     │
└─────────────────────────────────────┘
```

---

## 🎯 System Features Map

```
                    Dairy-X System
                         │
        ┌────────────────┼────────────────┐
        │                │                │
   User Portal      Admin Portal    Backend APIs
        │                │                │
        │                │                │
    ┌───┴───┐        ┌───┴───┐       ┌───┴───┐
    │       │        │       │       │       │
 Browse  Cart    Users  Orders   Auth  CRUD
 Products        Stats  Mgmt    APIs  Ops
```

---

**🎊 Your full-stack architecture is complete and production-ready!**
