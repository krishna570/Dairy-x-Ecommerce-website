# 🥛 Dairy-X E-Commerce Platform
## Full-Stack Web Application with PHP & MySQL

![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-blue)
![MySQL](https://img.shields.io/badge/MySQL-5.7%2B-orange)
![License](https://img.shields.io/badge/License-MIT-green)

**A complete full-stack e-commerce solution for dairy products with backend database integration, admin dashboard, and secure authentication.**

---

## 📋 Table of Contents

- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [System Architecture](#-system-architecture)
- [Installation](#-installation)
- [Usage](#-usage)
- [API Documentation](#-api-documentation)
- [Database Schema](#-database-schema)
- [Screenshots](#-screenshots)
- [Project Structure](#-project-structure)
- [Security](#-security)
- [Testing](#-testing)
- [Troubleshooting](#-troubleshooting)
- [Contributing](#-contributing)
- [License](#-license)
- [Author](#-author)

---

## ✨ Features

### 🛒 **Customer Features**
- ✅ User Registration & Authentication
- ✅ Product Browsing by Categories (Sweet, Milk, Cream)
- ✅ Persistent Shopping Cart (Database-backed)
- ✅ Real-time Cart Management
- ✅ Complete Checkout Process
- ✅ Multiple Payment Options (COD, PhonePe UPI, QR Code)
- ✅ Order History & Tracking
- ✅ Delivery Address Management

### 👨‍💼 **Admin Features**
- ✅ Secure Admin Dashboard
- ✅ Real-time Statistics & Analytics
- ✅ User Management
- ✅ Cart Monitoring (All active user carts)
- ✅ Order Management & Status Updates
- ✅ Revenue Tracking
- ✅ Product Overview

### 🔒 **Security Features**
- ✅ Password Hashing (bcrypt)
- ✅ SQL Injection Protection (Prepared Statements)
- ✅ Session-based Authentication
- ✅ Role-based Access Control
- ✅ Input Sanitization & Validation
- ✅ XSS Protection

---

## 🛠️ Tech Stack

### **Frontend**
- HTML5 & CSS3
- Vanilla JavaScript (ES6+)
- Font Awesome Icons
- Responsive Design

### **Backend**
- PHP 7.4+
- RESTful API Architecture
- MySQLi (Database Layer)
- Session Management

### **Database**
- MySQL 5.7+
- InnoDB Engine
- Foreign Key Constraints
- Transaction Support

### **Server**
- Apache (XAMPP)
- PHP Sessions
- AJAX for async requests

---

## 🏗️ System Architecture

```
┌─────────────┐      ┌───────────┐      ┌──────────┐
│   Browser   │ HTTP │  PHP APIs │ SQL  │  MySQL   │
│  (Client)   │─────▶│ (Backend) │─────▶│ Database │
│  JavaScript │◀─────│  REST API │◀─────│  Tables  │
└─────────────┘ JSON └───────────┘ Data └──────────┘
```

**See [ARCHITECTURE_DIAGRAM.md](ARCHITECTURE_DIAGRAM.md) for detailed architecture.**

---

## 📦 Installation

### **Prerequisites**
- XAMPP (or LAMP/WAMP) installed
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser (Chrome, Firefox, Edge)

### **Step-by-Step Setup**

#### 1. **Clone/Download Project**
```bash
# Place project in XAMPP htdocs folder
C:\xampp\htdocs\Project\
```

#### 2. **Start XAMPP**
- Open XAMPP Control Panel
- Start **Apache** server
- Start **MySQL** server

#### 3. **Create Database**
- Open **phpMyAdmin**: http://localhost/phpmyadmin
- Click **Import** tab
- Choose file: `database.sql`
- Click **Go** to execute

This creates:
- Database: `dairy_ecommerce`
- Tables: categories, products, users, cart, orders, order_items
- Sample data with 21 products
- Default admin user

#### 4. **Verify Configuration**
Open `config.php` and verify:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'dairy_ecommerce');
```

#### 5. **Access Application**
- Main Website: http://localhost/Project/index.php
- Admin Dashboard: http://localhost/Project/admin-dashboard.html
- Login Page: http://localhost/Project/login.html

---

## 🚀 Usage

### **For Customers**

1. **Register/Login**
   - Go to: http://localhost/Project/signup.html
   - Fill in your details
   - Or login with demo account

2. **Browse Products**
   - View products in Sweet, Milk, and Cream categories
   - Click "Add to Cart" to add products

3. **Manage Cart**
   - View cart: http://localhost/Project/cart.html
   - Update quantities
   - Remove items
   - Proceed to checkout

4. **Checkout**
   - Fill delivery details
   - Select payment method
   - Place order
   - Receive confirmation

### **For Administrators**

1. **Login as Admin**
   - Go to: http://localhost/Project/login.html
   - Click "Admin Login" tab
   - Username: `admin@dairy-x.com` or `admin`
   - Password: `admin123`

2. **Dashboard**
   - View real-time statistics
   - Monitor users, carts, and orders
   - Update order status
   - Track revenue

### **Default Credentials**

**Admin:**
- Email/Username: `admin@dairy-x.com` or `admin`
- Password: `admin123`

**Demo User:**
- Email: `demo@dairy-x.com`
- Password: `password`

---

## 📡 API Documentation

### **Base URL**
```
http://localhost/Project/api/
```

### **Authentication Endpoints**

#### Register User
```http
POST /api/auth.php?action=register
Content-Type: application/json

{
  "fullname": "John Doe",
  "email": "john@example.com",
  "phone": "+91 9876543210",
  "password": "securepassword"
}
```

#### User Login
```http
POST /api/auth.php?action=login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "securepassword"
}
```

#### Check Auth Status
```http
GET /api/auth.php?action=check
```

### **Cart Endpoints** (Requires Authentication)

#### Get Cart Items
```http
GET /api/cart.php?action=get
```

#### Add to Cart
```http
POST /api/cart.php?action=add
Content-Type: application/json

{
  "product_id": 1,
  "quantity": 2
}
```

#### Update Cart Item
```http
POST /api/cart.php?action=update
Content-Type: application/json

{
  "product_id": 1,
  "quantity": 5
}
```

#### Remove from Cart
```http
POST /api/cart.php?action=delete
Content-Type: application/json

{
  "product_id": 1
}
```

### **Order Endpoints** (Requires Authentication)

#### Place Order
```http
POST /api/orders.php?action=place
Content-Type: application/json

{
  "fullname": "John Doe",
  "phone": "+91 9876543210",
  "email": "john@example.com",
  "address": "123 Main St",
  "city": "Mumbai",
  "state": "Maharashtra",
  "pincode": "400001",
  "landmark": "Near Park",
  "payment_method": "cod",
  "items": [
    {
      "product_id": 1,
      "name": "Milk Cake",
      "price": 200,
      "quantity": 2
    }
  ]
}
```

#### Get User Orders
```http
GET /api/orders.php?action=get
```

### **Admin Endpoints** (Requires Admin Role)

#### Get All Users
```http
GET /api/admin.php?action=users
```

#### Get Dashboard Statistics
```http
GET /api/admin.php?action=statistics
```

#### Update Order Status
```http
POST /api/admin.php?action=update_order_status
Content-Type: application/json

{
  "order_id": 1,
  "status": "processing"
}
```

**Full API documentation: See [API_REFERENCE.md](API_REFERENCE.md)**

---

## 🗄️ Database Schema

### **Tables Overview**

```sql
categories
├── id (PRIMARY KEY)
├── name
├── slug
└── created_at

products
├── id (PRIMARY KEY)
├── category_id (FK → categories)
├── name
├── description
├── price
├── image
├── status
└── created_at

users
├── id (PRIMARY KEY)
├── fullname
├── email (UNIQUE)
├── phone
├── password_hash
├── role (user/admin)
└── created_at

cart
├── id (PRIMARY KEY)
├── user_id (FK → users)
├── product_id (FK → products)
├── quantity
└── added_at

orders
├── id (PRIMARY KEY)
├── user_id (FK → users)
├── fullname, phone, email
├── address, city, state, pincode
├── total_amount, delivery_fee, tax_amount
├── status
├── payment_method, payment_status
├── transaction_id
└── order_date

order_items
├── id (PRIMARY KEY)
├── order_id (FK → orders)
├── product_id (FK → products)
├── quantity
└── unit_price
```

**Database diagram: See [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md)**

---

## 📸 Screenshots

### Customer View
- Homepage with product listings
- Shopping cart page
- Checkout process
- Order confirmation

### Admin View
- Dashboard with statistics
- User management table
- Active carts monitoring
- Orders management

---

## 📁 Project Structure

```
Project/
├── api/                        # Backend API endpoints
│   ├── auth.php               # Authentication (login, register, logout)
│   ├── cart.php               # Cart operations (CRUD)
│   ├── orders.php             # Order management
│   └── admin.php              # Admin dashboard APIs
│
├── image/                      # Product images
├── Sweet/                      # Sweet product images
├── Milk/                       # Milk product images
│
├── index.php                   # Main homepage (product listing)
├── login.html                  # Login page
├── signup.html                 # Registration page
├── cart.html                   # Shopping cart page
├── checkout.html               # Checkout page
├── admin-dashboard.html        # Admin panel
│
├── config.php                  # Database configuration
├── database.sql                # Database schema & seed data
│
├── cart-backend.js             # Cart backend integration
├── login-backend.js            # Login backend integration
├── signup-backend.js           # Signup backend integration
├── admin-backend.js            # Admin dashboard integration
├── cart-page-backend.js        # Cart page integration
├── checkout-script.js          # Checkout backend integration
│
├── style.css                   # Global styles
│
└── Documentation/
    ├── BACKEND_SETUP_GUIDE.md
    ├── MIGRATION_SUMMARY.md
    ├── QUICK_REFERENCE.md
    ├── ARCHITECTURE_DIAGRAM.md
    └── README_FULLSTACK.md (this file)
```

---

## 🔒 Security

### **Implemented Security Measures**

1. **Password Security**
   - Passwords hashed using `password_hash()` (bcrypt)
   - Never stored in plain text
   - Secure verification with `password_verify()`

2. **SQL Injection Prevention**
   - All queries use prepared statements
   - Parameter binding for user inputs
   - Input validation and sanitization

3. **Session Management**
   - PHP sessions for authentication
   - Secure session handling
   - Role-based access control

4. **XSS Protection**
   - Output escaping with `htmlspecialchars()`
   - Content-Type headers set correctly
   - Input sanitization

5. **Authentication & Authorization**
   - Login required for cart/orders
   - Admin-only endpoints protected
   - Session validation on every request

### **For Production Deployment**

⚠️ **Additional security measures required:**
- Enable HTTPS (SSL/TLS)
- Use environment variables for DB credentials
- Implement CSRF token protection
- Add rate limiting
- Enable error logging (disable display_errors)
- Set secure session cookies
- Implement input validation libraries
- Add SQL audit logging

---

## 🧪 Testing

### **Manual Testing Checklist**

#### User Flow
- [ ] Register new account
- [ ] Login with credentials
- [ ] Browse products
- [ ] Add products to cart
- [ ] Update cart quantities
- [ ] Remove cart items
- [ ] Proceed to checkout
- [ ] Fill delivery details
- [ ] Place order with COD
- [ ] Verify order in database

#### Admin Flow
- [ ] Login as admin
- [ ] View dashboard statistics
- [ ] Check users list
- [ ] Monitor active carts
- [ ] View all orders
- [ ] Update order status
- [ ] Logout

### **Database Verification**

```sql
-- Verify users
SELECT * FROM users;

-- Check cart
SELECT c.*, u.email, p.name 
FROM cart c 
JOIN users u ON c.user_id = u.id 
JOIN products p ON c.product_id = p.id;

-- View orders
SELECT o.*, u.email 
FROM orders o 
JOIN users u ON o.user_id = u.id;

-- Order details
SELECT oi.*, p.name, o.id as order_num
FROM order_items oi
JOIN products p ON oi.product_id = p.id
JOIN orders o ON oi.order_id = o.id;
```

---

## 🐛 Troubleshooting

### **Common Issues & Solutions**

#### Issue: Can't access the site
**Solution:**
- Ensure XAMPP Apache is running
- Check URL: http://localhost/Project/index.php (not Dairy.html)
- Verify project is in `htdocs/Project/`

#### Issue: Database connection failed
**Solution:**
- Ensure MySQL is running in XAMPP
- Verify database `dairy_ecommerce` exists
- Check credentials in `config.php`

#### Issue: Products not showing
**Solution:**
- Import `database.sql` in phpMyAdmin
- Verify products exist: `SELECT * FROM products;`
- Check console for JavaScript errors

#### Issue: Can't login
**Solution:**
- Verify user exists in database
- Try default credentials (admin@dairy-x.com / admin123)
- Clear browser cache and cookies

#### Issue: Cart not working
**Solution:**
- Ensure user is logged in
- Check cart table exists
- Verify API endpoint accessible: http://localhost/Project/api/cart.php?action=get

#### Issue: Admin panel empty
**Solution:**
- Place some test orders first
- Check browser console for errors
- Verify admin role in users table

### **Debug Commands**

```sql
-- Check database exists
SHOW DATABASES LIKE 'dairy_ecommerce';

-- List all tables
SHOW TABLES;

-- Check sample data
SELECT COUNT(*) FROM products;
SELECT COUNT(*) FROM users WHERE role='admin';
SELECT * FROM categories;
```

### **Browser Console Debugging**

Press F12 to open Developer Tools and check:
- Console for JavaScript errors
- Network tab for API call failures
- Application tab for session storage

---

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 👨‍💻 Author

**Krishna Vinayak Solanke**  
FYMCA Project - Jawaharlal Nehru Engineering College  
MGM University, Aurangabad, Maharashtra, India

---

## 📞 Support

For issues, questions, or contributions:
- Open an issue on GitHub
- Email: info@dairy-x.com
- Documentation: See `BACKEND_SETUP_GUIDE.md`

---

## 🎯 Future Enhancements

Planned features for future versions:
- [ ] User profile page with order history
- [ ] Product search functionality
- [ ] Product reviews & ratings
- [ ] Email notifications for orders
- [ ] Inventory management
- [ ] Wishlist feature
- [ ] Coupon/discount codes
- [ ] Multi-image product gallery
- [ ] Real payment gateway integration
- [ ] Order tracking with delivery status
- [ ] Mobile app (React Native)

---

## 🙏 Acknowledgments

- Font Awesome for icons
- XAMPP for local server environment
- MySQL for database management
- PHP community for excellent documentation

---

## 📈 Project Stats

- **Total Lines of Code**: ~3,500+
- **Files Created**: 17 files
- **API Endpoints**: 15 endpoints
- **Database Tables**: 6 tables
- **Sample Products**: 21 products
- **Categories**: 3 categories

---

**⭐ If you like this project, please give it a star!**

**🎊 Thank you for using Dairy-X E-Commerce Platform! 🎊**

---

*Last Updated: 2025*
