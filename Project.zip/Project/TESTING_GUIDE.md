# 🧪 Testing Guide - Buy Now & Payment System

## How to Test Your New Features

### Prerequisites
✅ Make sure you have an account (if not, sign up first)
✅ Make sure you're logged in
✅ Open the website in a web browser

---

## Test 1: Buy Now Feature

### Steps:
1. Open `Dairy.html` in your browser
2. Scroll to any product (e.g., "Milk Cake")
3. Click the **🛍️ Buy Now** button
4. **Expected Result**: 
   - You should be redirected to `checkout.html`
   - The product should appear in the order summary
   - Delivery form should be visible

✅ **PASS** if checkout page loads with the product
❌ **FAIL** if nothing happens or you get an error

---

## Test 2: Add to Cart Feature

### Steps:
1. Open `Dairy.html` in your browser
2. Click **🛒 Add to Cart** on 3-4 different products
3. Notice the cart count increasing in the navigation (🛒Cart (4))
4. Click on **🛒Cart** link in navigation
5. **Expected Result**: 
   - Cart page shows all added items
   - Quantities and prices are correct
   - Total is calculated correctly

✅ **PASS** if all items appear in cart
❌ **FAIL** if cart is empty or items are missing

---

## Test 3: Cash on Delivery Payment

### Steps:
1. Go to checkout page (either via Buy Now or Cart → Checkout)
2. Fill in all delivery details:
   - Full Name: John Doe
   - Phone: +91 1234567890
   - Email: john@example.com
   - Address: 123 Main Street
   - City: Mumbai
   - Pin Code: 400001
   - State: Maharashtra
3. Keep **Cash on Delivery** selected (default)
4. Click **Place Order**
5. **Expected Result**: 
   - Success message appears with Order ID
   - Message says "Pay cash when you receive your order"
   - Redirected to home page
   - Cart is cleared

✅ **PASS** if order is placed successfully
❌ **FAIL** if you get an error

---

## Test 4: PhonePe UPI Payment

### Steps:
1. Go to checkout page
2. Fill in all delivery details
3. Click on **📱 PhonePe UPI** payment option
4. **Expected Result**: 
   - Payment option box highlights in green
   - UPI ID appears: `dairyx@ybl`
   - Transaction ID input field appears
   - Upload screenshot option appears
5. Enter transaction ID: `TEST123456789`
6. Click **Place Order**
7. **Expected Result**: 
   - Order placed successfully
   - Message says "Your payment will be verified shortly"

✅ **PASS** if payment details appear and order is placed
❌ **FAIL** if payment section doesn't show

---

## Test 5: QR Code Payment

### Steps:
1. Go to checkout page
2. Fill in all delivery details
3. Click on **📲 QR Code Payment** option
4. **Expected Result**: 
   - QR code icon appears with UPI ID
   - Transaction/Reference ID field appears
   - Upload screenshot option appears
5. Enter reference ID: `REF987654321`
6. Click **Place Order**
7. **Expected Result**: 
   - Order placed successfully
   - Payment status: "Verification Pending"

✅ **PASS** if QR payment section works
❌ **FAIL** if section doesn't appear

---

## Test 6: Form Validation

### Steps:
1. Go to checkout page
2. Leave some required fields empty
3. Click **Place Order**
4. **Expected Result**: 
   - Red error message appears at top
   - Says "Please fill all required fields"
   - Page scrolls to top
   - Order is NOT placed

✅ **PASS** if validation works
❌ **FAIL** if order is placed with empty fields

---

## Test 7: Transaction ID Validation (Online Payments)

### Steps:
1. Go to checkout page
2. Fill delivery details
3. Select **PhonePe UPI** or **QR Code Payment**
4. **Do NOT enter transaction ID**
5. Click **Place Order**
6. **Expected Result**: 
   - Error message: "Please enter the transaction ID"
   - Order is NOT placed

✅ **PASS** if validation prevents order
❌ **FAIL** if order is placed without transaction ID

---

## Test 8: Order Summary Display

### Steps:
1. Add multiple products to cart with different quantities
2. Go to checkout
3. Check the right sidebar (Order Summary)
4. **Expected Result**: 
   - All items listed with correct quantities
   - Subtotal calculated correctly
   - Delivery fee: $5.00
   - Tax (5%) calculated correctly
   - Total = Subtotal + Delivery + Tax

✅ **PASS** if all calculations are correct
❌ **FAIL** if totals are wrong

---

## Test 9: Login Requirement

### Steps:
1. **Log out** of your account
2. Try to click **Buy Now** or go to checkout
3. **Expected Result**: 
   - Alert message: "Please login to proceed"
   - Redirected to login page
   - Cannot access checkout without login

✅ **PASS** if login is enforced
❌ **FAIL** if you can checkout without logging in

---

## Test 10: File Upload (Optional)

### Steps:
1. Go to checkout
2. Select PhonePe or QR Code payment
3. Click **Upload Payment Screenshot**
4. Select an image file
5. **Expected Result**: 
   - File name appears below button
   - Green checkmark icon shows
   - Message: "✓ filename.jpg"

✅ **PASS** if file upload works
❌ **FAIL** if nothing happens

---

## Test 11: Responsive Design

### Steps:
1. Open checkout page
2. Resize browser window to mobile size (320px width)
3. **Expected Result**: 
   - Layout adjusts to single column
   - All buttons remain clickable
   - Text is readable
   - No horizontal scrolling

✅ **PASS** if mobile view looks good
❌ **FAIL** if layout breaks

---

## Test 12: Payment Method Switching

### Steps:
1. Go to checkout page
2. Click **Cash on Delivery** → Payment details hidden
3. Click **PhonePe UPI** → PhonePe details appear, QR hidden
4. Click **QR Code Payment** → QR details appear, PhonePe hidden
5. Click **Cash on Delivery** again → All details hidden
6. **Expected Result**: 
   - Only selected payment details visible
   - Smooth transition between options
   - Radio buttons update correctly

✅ **PASS** if switching works smoothly
❌ **FAIL** if multiple sections show at once

---

## 🔍 Browser Console Testing

### Check for JavaScript Errors:
1. Press **F12** to open Developer Tools
2. Go to **Console** tab
3. Perform any action (Buy Now, Add to Cart, etc.)
4. **Expected Result**: 
   - No red error messages
   - Only informational messages (if any)

✅ **PASS** if console is clean
❌ **FAIL** if red errors appear

---

## 📱 Mobile Device Testing

### If you have a smartphone:
1. Open the website on your phone
2. Test all buttons and forms
3. **Expected Result**: 
   - Touch targets are large enough
   - Text is readable without zooming
   - Forms are easy to fill
   - Payment options work on mobile

✅ **PASS** if mobile experience is smooth
❌ **FAIL** if hard to use on mobile

---

## 📊 Test Results Template

Copy this and fill it out:

```
=================================
DAIRY-X TESTING RESULTS
=================================

Date: _______________
Browser: _______________

Test 1 - Buy Now: ⬜ PASS ⬜ FAIL
Test 2 - Add to Cart: ⬜ PASS ⬜ FAIL
Test 3 - COD Payment: ⬜ PASS ⬜ FAIL
Test 4 - PhonePe UPI: ⬜ PASS ⬜ FAIL
Test 5 - QR Code: ⬜ PASS ⬜ FAIL
Test 6 - Form Validation: ⬜ PASS ⬜ FAIL
Test 7 - Transaction Validation: ⬜ PASS ⬜ FAIL
Test 8 - Order Summary: ⬜ PASS ⬜ FAIL
Test 9 - Login Requirement: ⬜ PASS ⬜ FAIL
Test 10 - File Upload: ⬜ PASS ⬜ FAIL
Test 11 - Responsive Design: ⬜ PASS ⬜ FAIL
Test 12 - Payment Switching: ⬜ PASS ⬜ FAIL

Overall Status: ⬜ ALL PASS ⬜ SOME FAILURES

Notes:
_________________________________
_________________________________
```

---

## 🐛 Common Issues & Solutions

### Issue: Buy Now button does nothing
**Solution**: Make sure you're logged in first

### Issue: Checkout page shows empty cart
**Solution**: Add items to cart before clicking checkout

### Issue: Can't submit order
**Solution**: Fill all required fields (marked with *)

### Issue: Transaction ID not accepted
**Solution**: Make sure you selected online payment method first

### Issue: Page not loading
**Solution**: Clear browser cache and refresh (Ctrl+F5)

---

## ✅ Success Criteria

Your implementation is successful if:
- ✅ All products have working Buy Now buttons
- ✅ All products have working Add to Cart buttons
- ✅ Cart displays items correctly
- ✅ Checkout page loads properly
- ✅ All 3 payment methods are selectable
- ✅ PhonePe shows UPI ID: dairyx@ybl
- ✅ Form validation prevents incomplete orders
- ✅ Orders are saved to localStorage
- ✅ Success messages appear after order
- ✅ Cart clears after successful order

---

## 🎉 Final Check

After all tests pass:
1. Place a complete order using each payment method
2. Check browser localStorage (F12 → Application → Local Storage)
3. Verify `orderHistory` contains your orders
4. Each order should have:
   - Order ID
   - Customer details
   - Items list
   - Payment method
   - Total amount
   - Timestamp

**If all above are present, your system is FULLY FUNCTIONAL! 🎊**

---

Happy Testing! 🚀
