# ✅ Dairy-X Installation Checklist

## Pre-Installation Requirements

- [ ] XAMPP installed (download from https://www.apachefriends.org)
- [ ] PHP 7.4 or higher available
- [ ] MySQL 5.7 or higher available
- [ ] Modern web browser (Chrome, Firefox, Edge)
- [ ] Project files downloaded/extracted to `C:\xampp\htdocs\Project\`

---

## Installation Steps

### Step 1: Verify File Structure ✅
- [ ] Navigate to `C:\xampp\htdocs\Project\`
- [ ] Verify following folders exist:
  - [ ] `api/` folder with 4 PHP files
  - [ ] `image/` folder
  - [ ] `Sweet/` folder
  - [ ] `Milk/` folder
- [ ] Verify following files exist:
  - [ ] `index.php`
  - [ ] `config.php`
  - [ ] `database.sql`
  - [ ] All HTML files (login, signup, cart, etc.)
  - [ ] All JS files (cart-backend, login-backend, etc.)

### Step 2: Start XAMPP Servers ✅
- [ ] Open XAMPP Control Panel
- [ ] Click "Start" for **Apache** module
  - [ ] Wait for green "Running" status
- [ ] Click "Start" for **MySQL** module
  - [ ] Wait for green "Running" status
- [ ] Both servers should show green status

### Step 3: Create Database ✅
- [ ] Open browser and go to: http://localhost/phpmyadmin
- [ ] phpMyAdmin opens successfully
- [ ] Click on "Import" tab
- [ ] Click "Choose File" button
- [ ] Navigate to: `C:\xampp\htdocs\Project\database.sql`
- [ ] Select `database.sql` file
- [ ] Click "Go" button at bottom
- [ ] Wait for success message
- [ ] Verify database created:
  - [ ] Click "dairy_ecommerce" in left sidebar
  - [ ] You should see 6 tables:
    - [ ] categories
    - [ ] products
    - [ ] users
    - [ ] cart
    - [ ] orders
    - [ ] order_items

### Step 4: Verify Database Data ✅
- [ ] Click on "categories" table
- [ ] Click "Browse" tab
- [ ] Verify 3 categories exist: Sweet, Milk, Cream
- [ ] Click on "products" table
- [ ] Click "Browse" tab
- [ ] Verify 21 products exist
- [ ] Click on "users" table
- [ ] Click "Browse" tab
- [ ] Verify 2 users exist (Admin and Demo user)

### Step 5: Verify Configuration ✅
- [ ] Open `C:\xampp\htdocs\Project\config.php` in text editor
- [ ] Verify database settings:
  ```php
  DB_HOST = 'localhost'      ✓
  DB_USER = 'root'           ✓
  DB_PASS = ''               ✓ (empty)
  DB_NAME = 'dairy_ecommerce' ✓
  ```
- [ ] Save file if any changes made

### Step 6: Test Main Website ✅
- [ ] Open browser
- [ ] Go to: http://localhost/Project/index.php
- [ ] Page loads successfully
- [ ] You see "Dairy Product" heading
- [ ] Image gallery visible at top
- [ ] Navigation menu visible
- [ ] Three product sections visible:
  - [ ] Sweet Products
  - [ ] Milk Products
  - [ ] Cream Products
- [ ] Products display with images and prices
- [ ] Cart count shows (0)

### Step 7: Test User Registration ✅
- [ ] Go to: http://localhost/Project/signup.html
- [ ] Page loads successfully
- [ ] Fill in the form:
  - Full Name: `Test User`
  - Email: `test@example.com`
  - Phone: `+91 9999999999`
  - Password: `test123`
  - Confirm Password: `test123`
- [ ] Click "Sign Up" button
- [ ] Success message appears
- [ ] Redirected to index.php
- [ ] Verify in database:
  - [ ] Open phpMyAdmin
  - [ ] Select `dairy_ecommerce` database
  - [ ] Click `users` table
  - [ ] Find `test@example.com` user
  - [ ] Password is hashed (not plain text)

### Step 8: Test User Login ✅
- [ ] Go to: http://localhost/Project/login.html
- [ ] Ensure "User Login" tab is selected
- [ ] Enter credentials:
  - Email: `test@example.com`
  - Password: `test123`
- [ ] Click "Login as User" button
- [ ] Success message appears
- [ ] Redirected to index.php
- [ ] Navigation shows your username (not "LOG IN")

### Step 9: Test Add to Cart ✅
- [ ] Ensure you're logged in
- [ ] Scroll to any product
- [ ] Click "🛒 Add to Cart" button
- [ ] Alert shows "added to cart"
- [ ] Cart count increases (0 → 1)
- [ ] Verify in database:
  - [ ] Open phpMyAdmin
  - [ ] Click `cart` table
  - [ ] See your product in cart with quantity 1
- [ ] Add same product again
- [ ] Cart count increases
- [ ] In database, quantity should increase (not new row)

### Step 10: Test Cart Page ✅
- [ ] Click "🛒Cart (X)" in navigation
- [ ] Cart page loads: http://localhost/Project/cart.html
- [ ] Your cart items display
- [ ] Product name, price, quantity visible
- [ ] Order summary shows:
  - [ ] Subtotal
  - [ ] Delivery Fee (₹50.00)
  - [ ] Tax (5%)
  - [ ] Total amount
- [ ] Test quantity controls:
  - [ ] Click "+" button → quantity increases
  - [ ] Click "-" button → quantity decreases
  - [ ] Summary updates automatically
- [ ] Click "Remove" button
- [ ] Item removed from cart
- [ ] Cart count updates

### Step 11: Test Checkout & Order ✅
- [ ] Add products to cart
- [ ] Click "Proceed to Checkout" button
- [ ] Checkout page loads
- [ ] Form fields pre-filled with your details
- [ ] Fill missing fields:
  - [ ] Phone number
  - [ ] Delivery address
  - [ ] City
  - [ ] Pin code
  - [ ] State
- [ ] Select payment method:
  - [ ] Cash on Delivery (COD)
- [ ] Review order summary
- [ ] Click "Place Order" button
- [ ] Success message with Order ID
- [ ] Redirected to index.php
- [ ] Verify in database:
  - [ ] Open `orders` table
  - [ ] See your order with all details
  - [ ] Open `order_items` table
  - [ ] See order items linked to order
  - [ ] Open `cart` table
  - [ ] Your cart should be empty

### Step 12: Test Admin Login ✅
- [ ] Go to: http://localhost/Project/login.html
- [ ] Click "Admin Login" tab
- [ ] Enter credentials:
  - Username: `admin`
  - Password: `admin123`
- [ ] Click "Login as Admin" button
- [ ] Success message appears
- [ ] Redirected to admin dashboard

### Step 13: Test Admin Dashboard ✅
- [ ] Dashboard loads successfully
- [ ] Statistics cards display:
  - [ ] Total Users (should show 2+)
  - [ ] Total Orders (should show your test order)
  - [ ] Total Revenue (sum of order amounts)
  - [ ] Total Products (21)
- [ ] Click "All Users" tab:
  - [ ] Users table displays
  - [ ] Shows registered users
- [ ] Click "User Carts" tab:
  - [ ] Shows active carts (if any)
- [ ] Click "Order History" tab:
  - [ ] Shows all orders
  - [ ] Your test order visible
  - [ ] Click "View" button → order details popup
  - [ ] Change order status dropdown
  - [ ] Select new status → order updates

### Step 14: Test Logout ✅
- [ ] Click "Logout" in navigation
- [ ] Confirmation prompt appears
- [ ] Click "OK"
- [ ] Success message shows
- [ ] Redirected to login page
- [ ] Navigation shows "LOG IN" again

---

## Post-Installation Verification

### Database Integrity ✅
```sql
-- Run these queries in phpMyAdmin SQL tab

-- Check all tables exist
SHOW TABLES;
-- Should show: cart, categories, order_items, orders, products, users

-- Check foreign keys
SELECT * FROM information_schema.KEY_COLUMN_USAGE 
WHERE TABLE_SCHEMA = 'dairy_ecommerce' 
AND REFERENCED_TABLE_NAME IS NOT NULL;
-- Should show all FK relationships

-- Check products count
SELECT COUNT(*) FROM products;
-- Should return: 21

-- Check categories
SELECT * FROM categories;
-- Should show: Sweet, Milk, Cream
```

### API Endpoints ✅
Test these URLs (while logged in):
- [ ] http://localhost/Project/api/auth.php?action=check
  - Should return: `{"success":true,"authenticated":true,"user":{...}}`
- [ ] http://localhost/Project/api/cart.php?action=get
  - Should return: `{"success":true,"items":[...]}`
- [ ] http://localhost/Project/api/admin.php?action=statistics (as admin)
  - Should return: `{"success":true,"statistics":{...}}`

### File Permissions ✅
- [ ] All PHP files are readable
- [ ] `config.php` is accessible
- [ ] Image folders are readable
- [ ] No 403 Forbidden errors

---

## Troubleshooting Common Issues

### ❌ Apache won't start
**Solution:**
- [ ] Check if port 80 is in use (Skype, IIS)
- [ ] Change Apache port in XAMPP config
- [ ] Run XAMPP as Administrator

### ❌ MySQL won't start
**Solution:**
- [ ] Check if port 3306 is in use
- [ ] Stop other MySQL services
- [ ] Run XAMPP as Administrator

### ❌ "Database connection failed"
**Solution:**
- [ ] Verify MySQL is running
- [ ] Check database name in config.php
- [ ] Ensure database was imported
- [ ] Check credentials: root / (empty password)

### ❌ "Unauthorized" error
**Solution:**
- [ ] Clear browser cache
- [ ] Logout and login again
- [ ] Check browser console for errors

### ❌ Products not showing
**Solution:**
- [ ] Re-import database.sql
- [ ] Check products table has data
- [ ] Verify image paths exist

### ❌ Cart not working
**Solution:**
- [ ] Ensure logged in
- [ ] Check cart table exists
- [ ] Verify product IDs match database

---

## Final Checklist

- [ ] XAMPP servers running (Apache + MySQL)
- [ ] Database imported successfully
- [ ] User registration works
- [ ] User login works
- [ ] Products display correctly
- [ ] Add to cart works
- [ ] Cart page functional
- [ ] Checkout and order placement works
- [ ] Orders saved to database
- [ ] Admin login works
- [ ] Admin dashboard displays data
- [ ] Order status updates work
- [ ] Logout works

---

## 🎉 Success!

If all items are checked, your Dairy-X E-Commerce Platform is fully installed and operational!

### Next Steps:
1. Review [QUICK_REFERENCE.md](QUICK_REFERENCE.md) for quick commands
2. Read [BACKEND_SETUP_GUIDE.md](BACKEND_SETUP_GUIDE.md) for detailed documentation
3. Check [ARCHITECTURE_DIAGRAM.md](ARCHITECTURE_DIAGRAM.md) to understand system design
4. Explore [README_FULLSTACK.md](README_FULLSTACK.md) for complete project overview

---

**📧 Need Help?**  
Check the Troubleshooting section or review the documentation files.

**🚀 Happy E-Commerce!**
