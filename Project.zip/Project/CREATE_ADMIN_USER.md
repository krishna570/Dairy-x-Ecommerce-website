# 🔐 Create Admin User in Database - Complete Guide

## Problem
Admin user is not created in the database, so you cannot access the admin panel.

---

## ✅ SOLUTION - 3 Easy Methods

Choose the method that works best for you:

---

## 🚀 METHOD 1: Import SQL File (Easiest & Recommended)

### **Step 1: Open phpMyAdmin**
- Go to: http://localhost/phpmyadmin
- Login (usually no username/password needed)

### **Step 2: Select Database**
- Click on `dairy_ecommerce` in the left sidebar
- If database doesn't exist, create it first (see Method 2)

### **Step 3: Import SQL File**
- Click on **"Import"** tab at the top
- Click **"Choose File"** button
- Navigate to: `c:\xampp\htdocs\Project\create_admin_user.sql`
- Click **"Go"** button at the bottom

### **Step 4: Verify Success**
You should see a message: "Admin user created successfully!"

✅ **Done! Your admin user is now created!**

### **Your Credentials:**
```
Username: admin
   OR
Email: admin@dairy-x.com
Password: admin123
```

---

## 📝 METHOD 2: Run SQL Query Manually

### **Step 1: Open phpMyAdmin**
Go to: http://localhost/phpmyadmin

### **Step 2: Create Database (if it doesn't exist)**
```sql
CREATE DATABASE IF NOT EXISTS dairy_ecommerce 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE dairy_ecommerce;
```

### **Step 3: Create Users Table (if it doesn't exist)**
```sql
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
```

### **Step 4: Create Admin User**
```sql
-- Delete existing admin if any
DELETE FROM users WHERE email = 'admin@dairy-x.com' AND role = 'admin';

-- Create new admin user
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES (
    'Admin User',
    'admin@dairy-x.com',
    '+91 9000000000',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'admin'
);
```

### **Step 5: Verify Admin User**
```sql
SELECT 
    id,
    fullname,
    email,
    role,
    'Password: admin123' as password_info
FROM users 
WHERE role = 'admin';
```

You should see the admin user details!

---

## 🔄 METHOD 3: Re-import Complete Database

If you want a fresh start with all tables and data:

### **Step 1: Open phpMyAdmin**
http://localhost/phpmyadmin

### **Step 2: Drop Existing Database (Optional)**
Only do this if you want to start completely fresh:
```sql
DROP DATABASE IF EXISTS dairy_ecommerce;
```

### **Step 3: Import Complete Database**
- Click on "Import" tab
- Choose file: `c:\xampp\htdocs\Project\database.sql`
- Click "Go"
- Wait for import to complete

This will create:
- ✅ Database: `dairy_ecommerce`
- ✅ All tables (users, products, categories, cart, orders, order_items)
- ✅ Admin user with credentials
- ✅ Sample products

---

## 🧪 VERIFY ADMIN USER EXISTS

### **Check in phpMyAdmin:**

1. Select `dairy_ecommerce` database
2. Click on `users` table
3. Click "Browse" tab
4. You should see:

```
┌────┬─────────────┬─────────────────────┬──────┬────────┐
│ id │ fullname    │ email               │ role │        │
├────┼─────────────┼─────────────────────┼──────┼────────┤
│ 1  │ Admin User  │ admin@dairy-x.com   │admin │  ...   │
│ 2  │ Demo User   │ demo@dairy-x.com    │user  │  ...   │
└────┴─────────────┴─────────────────────┴──────┴────────┘
```

### **Check with SQL Query:**
```sql
SELECT * FROM users WHERE role = 'admin';
```

Should return at least one admin user.

---

## 🔐 YOUR ADMIN CREDENTIALS

After creating the admin user, use these credentials:

### **Login Option 1:**
```
Username: admin
Password: admin123
```

### **Login Option 2:**
```
Email: admin@dairy-x.com
Password: admin123
```

Both work! The system accepts both formats.

---

## 🎯 TEST ADMIN LOGIN

### **Step 1: Go to Login Page**
http://localhost/Project/login.html

### **Step 2: Click "Admin Login" Tab**
Make sure you're on the ADMIN LOGIN tab, not user login!

### **Step 3: Enter Credentials**
- Username: `admin`
- Password: `admin123`

### **Step 4: Click "Login as Admin"**

### **Step 5: Verify Success**
You should be redirected to:
http://localhost/Project/admin-dashboard.html

And see:
- ✅ Dashboard statistics
- ✅ User management tab
- ✅ Cart monitoring tab
- ✅ Order history tab

---

## 📋 COMPLETE SQL SCRIPT

If you want to copy-paste everything at once in phpMyAdmin SQL tab:

```sql
-- ============================================
-- COMPLETE ADMIN USER CREATION SCRIPT
-- ============================================

-- Use the database
USE dairy_ecommerce;

-- Create users table if it doesn't exist
CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  fullname VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  phone VARCHAR(20) NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Delete any existing admin user
DELETE FROM users WHERE email = 'admin@dairy-x.com';

-- Create admin user
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES (
    'Admin User',
    'admin@dairy-x.com',
    '+91 9000000000',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'admin'
);

-- Create demo user (optional)
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES (
    'Demo User',
    'demo@dairy-x.com',
    '+91 9876543210',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'user'
)
ON DUPLICATE KEY UPDATE fullname = 'Demo User';

-- Verify admin user
SELECT 
    '✅ Admin user created successfully!' as status,
    id,
    fullname,
    email,
    role,
    'Password: admin123' as credentials
FROM users 
WHERE role = 'admin';

-- ============================================
-- DONE! Login with: admin / admin123
-- ============================================
```

---

## 🛠️ TROUBLESHOOTING

### Issue 1: "Table 'dairy_ecommerce.users' doesn't exist"

**Solution:**
First create the database and tables:
```sql
-- Create database
CREATE DATABASE IF NOT EXISTS dairy_ecommerce;
USE dairy_ecommerce;

-- Import the complete database.sql file
-- OR create tables manually (see METHOD 2 above)
```

Then import `database.sql` from phpMyAdmin.

---

### Issue 2: "Duplicate entry 'admin@dairy-x.com'"

**Solution:**
Admin already exists! Just update the password:
```sql
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'admin@dairy-x.com';
```

---

### Issue 3: Database doesn't exist

**Solution:**
Create it first:
```sql
CREATE DATABASE dairy_ecommerce 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;
```

Then import `database.sql` file.

---

### Issue 4: Still can't login after creating admin

**Solution:**
1. Clear browser cache (Ctrl + Shift + Delete)
2. Try incognito mode (Ctrl + Shift + N)
3. Make sure you're clicking "Admin Login" tab
4. Check credentials are exactly: `admin` / `admin123`
5. Run the verification SQL to confirm admin exists

---

## 📦 FILES CREATED FOR YOU

I've created these files to help you:

1. **`create_admin_user.sql`** ⭐
   - Ready-to-import SQL file
   - Creates admin user automatically
   - Location: `c:\xampp\htdocs\Project\create_admin_user.sql`

2. **`database.sql`** (Updated)
   - Contains admin user creation
   - Contains all tables and sample data
   - Location: `c:\xampp\htdocs\Project\database.sql`

3. **This guide**: `CREATE_ADMIN_USER.md`

---

## ✅ QUICK STEPS SUMMARY

1. **Open phpMyAdmin**: http://localhost/phpmyadmin
2. **Click "Import" tab**
3. **Choose file**: `create_admin_user.sql`
4. **Click "Go"**
5. **Login**: http://localhost/Project/login.html
6. **Use credentials**: `admin` / `admin123`

---

## 🎓 UNDERSTANDING THE PASSWORD

The password `admin123` is stored in the database as:
```
$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC
```

This is a **bcrypt hash**. It's a one-way encryption that:
- ✅ Keeps your password secure
- ✅ Cannot be reversed to get the original password
- ✅ Is verified using PHP's `password_verify()` function

You type `admin123`, but the database stores the hash for security!

---

## 🎯 SUCCESS CHECKLIST

- [ ] XAMPP Apache is running (green)
- [ ] XAMPP MySQL is running (green)
- [ ] Opened phpMyAdmin
- [ ] Database `dairy_ecommerce` exists
- [ ] Table `users` exists
- [ ] Ran create_admin_user.sql OR the complete SQL script
- [ ] Verified admin user exists (SELECT query)
- [ ] Went to login.html
- [ ] Clicked "Admin Login" tab
- [ ] Entered: admin / admin123
- [ ] Successfully logged into admin dashboard

---

## 🚀 FASTEST METHOD

**Just do this:**

1. Open: http://localhost/phpmyadmin
2. Click "Import"
3. Choose: `c:\xampp\htdocs\Project\create_admin_user.sql`
4. Click "Go"
5. Login: http://localhost/Project/login.html (admin/admin123)

**Done in 30 seconds! 🎉**

---

## 📞 NEED MORE HELP?

If still not working:
- Check: `check_admin.php` (http://localhost/Project/check_admin.php)
- Read: `ADMIN_ACCESS_HELP.md`
- Or: `fix-admin-login.html`

---

**🎊 Your admin user will be created and you can access the admin panel!**
