// Checkout Script for Dairy-X - Backend Integration
const API_BASE = 'api';
let cart = [];
let selectedPayment = 'cod';
let currentUser = null;

// Load cart and user data on page load
window.addEventListener('load', async function() {
    // Check if user is logged in
    await checkAuthentication();
    
    if (!currentUser) {
        alert('Please login to proceed with checkout');
        window.location.href = 'login.html';
        return;
    }
    
    await loadCart();
    loadUserData();
    displayOrderSummary();
});

// Check authentication
async function checkAuthentication() {
    try {
        const response = await fetch(`${API_BASE}/auth.php?action=check`);
        const data = await response.json();
        
        if (data.success && data.authenticated) {
            currentUser = data.user;
        } else {
            currentUser = null;
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        currentUser = null;
    }
}

// Load cart from backend or session storage for quick buy
async function loadCart() {
    // Check for quick buy item
    const quickBuyItem = sessionStorage.getItem('quickBuyItem');
    if (quickBuyItem) {
        cart = [JSON.parse(quickBuyItem)];
        sessionStorage.removeItem('quickBuyItem');
        return;
    }
    
    // Load from backend
    try {
        const response = await fetch(`${API_BASE}/cart.php?action=get`);
        const data = await response.json();
        
        if (data.success) {
            cart = data.items;
        }
    } catch (error) {
        console.error('Failed to load cart:', error);
    }
    
    if (cart.length === 0) {
        alert('Your cart is empty!');
        window.location.href = 'index.php';
    }
}

// Load user data and pre-fill form
function loadUserData() {
    if (currentUser) {
        if (currentUser.fullname) {
            document.getElementById('fullName').value = currentUser.fullname;
        }
        
        if (currentUser.email) {
            document.getElementById('email').value = currentUser.email;
        }
        
        if (currentUser.phone) {
            document.getElementById('phone').value = currentUser.phone;
        }
    }
}

// Display order summary
function displayOrderSummary() {
    const orderItemsDiv = document.getElementById('orderItems');
    let itemsHTML = '';
    let subtotal = 0;
    
    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        subtotal += itemTotal;
        
        itemsHTML += `
            <div class="order-item">
                <div class="item-details">
                    <div class="item-name">${item.name}</div>
                    <div class="item-qty">Quantity: ${item.quantity}</div>
                </div>
                <div class="item-price">$${itemTotal.toFixed(2)}</div>
            </div>
        `;
    });
    
    orderItemsDiv.innerHTML = itemsHTML;
    
    const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const tax = subtotal * 0.05;
    const total = subtotal + 5 + tax;
    
    document.getElementById('itemCount').textContent = itemCount;
    document.getElementById('subtotal').textContent = subtotal.toFixed(2);
    document.getElementById('tax').textContent = tax.toFixed(2);
    document.getElementById('total').textContent = total.toFixed(2);
}

// Select payment method
function selectPayment(method) {
    selectedPayment = method;
    
    // Update radio buttons
    const radios = document.querySelectorAll('input[name="payment"]');
    radios.forEach(radio => {
        radio.checked = (radio.value === method);
    });
    
    // Update selected class
    const options = document.querySelectorAll('.payment-option');
    options.forEach(option => {
        option.classList.remove('selected');
    });
    event.currentTarget.classList.add('selected');
    
    // Show/hide payment details
    document.getElementById('phonepeDetails').classList.remove('active');
    document.getElementById('qrcodeDetails').classList.remove('active');
    
    if (method === 'phonepe') {
        document.getElementById('phonepeDetails').classList.add('active');
    } else if (method === 'qrcode') {
        document.getElementById('qrcodeDetails').classList.add('active');
    }
}

// Show uploaded file name
function showFileName() {
    const file = document.getElementById('screenshot').files[0];
    const fileNameDiv = document.getElementById('fileName');
    
    if (file) {
        fileNameDiv.innerHTML = `<i class="fas fa-check-circle" style="color: #04AA6D;"></i> ${file.name}`;
    }
}

function showQRFileName() {
    const file = document.getElementById('qrScreenshot').files[0];
    const fileNameDiv = document.getElementById('qrFileName');
    
    if (file) {
        fileNameDiv.innerHTML = `<i class="fas fa-check-circle" style="color: #04AA6D;"></i> ${file.name}`;
    }
}

// Validate form
function validateForm() {
    const fullName = document.getElementById('fullName').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const email = document.getElementById('email').value.trim();
    const address = document.getElementById('address').value.trim();
    const city = document.getElementById('city').value.trim();
    const pincode = document.getElementById('pincode').value.trim();
    const state = document.getElementById('state').value.trim();
    
    if (!fullName || !phone || !email || !address || !city || !pincode || !state) {
        showError('Please fill all required fields');
        return false;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showError('Please enter a valid email address');
        return false;
    }
    
    // Phone validation
    const phoneRegex = /^[0-9+\s-]{10,}$/;
    if (!phoneRegex.test(phone)) {
        showError('Please enter a valid phone number');
        return false;
    }
    
    // Validate transaction ID for online payments
    if (selectedPayment === 'phonepe') {
        const transactionId = document.getElementById('transactionId').value.trim();
        if (!transactionId) {
            showError('Please enter the PhonePe transaction ID');
            return false;
        }
    }
    
    if (selectedPayment === 'qrcode') {
        const qrTransactionId = document.getElementById('qrTransactionId').value.trim();
        if (!qrTransactionId) {
            showError('Please enter the transaction/reference ID');
            return false;
        }
    }
    
    return true;
}

// Place order
async function placeOrder() {
    if (!validateForm()) {
        return;
    }
    
    // Prepare order data
    const orderData = {
        fullname: document.getElementById('fullName').value.trim(),
        phone: document.getElementById('phone').value.trim(),
        email: document.getElementById('email').value.trim(),
        address: document.getElementById('address').value.trim(),
        city: document.getElementById('city').value.trim(),
        state: document.getElementById('state').value.trim(),
        pincode: document.getElementById('pincode').value.trim(),
        landmark: document.getElementById('landmark').value.trim(),
        payment_method: selectedPayment,
        items: cart.map(item => ({
            product_id: item.product_id || item.id,
            name: item.name,
            price: item.price,
            quantity: item.quantity
        }))
    };
    
    // Add transaction ID for online payments
    if (selectedPayment === 'phonepe') {
        orderData.transaction_id = document.getElementById('transactionId').value.trim();
    } else if (selectedPayment === 'qrcode') {
        orderData.transaction_id = document.getElementById('qrTransactionId').value.trim();
    }
    
    try {
        const response = await fetch(`${API_BASE}/orders.php?action=place`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(orderData)
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Show success message
            let successMsg = `Order Placed Successfully!\n\n`;
            successMsg += `Order ID: #ORD${String(data.order_id).padStart(4, '0')}\n`;
            successMsg += `Total Amount: ₹${data.total_amount.toFixed(2)}\n`;
            successMsg += `Payment Method: ${getPaymentMethodName()}\n\n`;
            
            if (selectedPayment === 'cod') {
                successMsg += 'Pay cash when you receive your order.\n';
            } else {
                successMsg += 'Your payment will be verified shortly.\n';
            }
            
            successMsg += '\nThank you for shopping with Dairy-X!';
            
            alert(successMsg);
            
            // Redirect to home page
            window.location.href = 'index.php';
        } else {
            showError('Failed to place order: ' + data.message);
        }
    } catch (error) {
        console.error('Place order failed:', error);
        showError('Failed to place order. Please try again.');
    }
}

// Get payment method name
function getPaymentMethodName() {
    switch(selectedPayment) {
        case 'cod':
            return 'Cash on Delivery';
        case 'phonepe':
            return 'PhonePe UPI';
        case 'qrcode':
            return 'QR Code Payment';
        default:
            return 'Cash on Delivery';
    }
}

// Show error message
function showError(message) {
    const errorDiv = document.getElementById('errorMessage');
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    
    setTimeout(() => {
        errorDiv.style.display = 'none';
    }, 5000);
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
