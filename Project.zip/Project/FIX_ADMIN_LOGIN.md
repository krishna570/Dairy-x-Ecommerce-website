# 🔧 Fix Admin Login "Unauthorized" Error

## Problem
When trying to log into the admin panel, you get an "Unauthorized access! Admin login required" error.

---

## Root Cause
The admin password hash in the database doesn't match the password `admin123`. This happens because the initial database had a placeholder password hash.

---

## ✅ Solution (Choose One Method)

### **Method 1: Update Existing Database (Quick Fix)**

If you've already imported the database and have data you want to keep:

#### Step 1: Open phpMyAdmin
- Go to: http://localhost/phpmyadmin
- Login (usually no password needed)
- Select database: `dairy_ecommerce`

#### Step 2: Click "SQL" Tab

#### Step 3: Run This SQL Query
```sql
-- Update admin password to 'admin123'
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'admin@dairy-x.com' AND role = 'admin';

-- Update demo user password to 'password'
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'demo@dairy-x.com' AND role = 'user';
```

#### Step 4: Click "Go"
- You should see: "2 rows affected"

#### Step 5: Test Login
- Go to: http://localhost/Project/login.html
- Click "Admin Login" tab
- Username: `admin` or `admin@dairy-x.com`
- Password: `admin123`
- Click "Login as Admin"

---

### **Method 2: Re-import Database (Fresh Start)**

If you want a completely fresh database:

#### Step 1: Open phpMyAdmin
- Go to: http://localhost/phpmyadmin

#### Step 2: Drop Existing Database
- Click on `dairy_ecommerce` in left sidebar
- Click "Operations" tab
- Scroll down to "Remove database"
- Click "Drop the database (DROP)"
- Confirm deletion

#### Step 3: Import Updated Database
- Click "Import" tab
- Click "Choose File"
- Select: `c:\xampp\htdocs\Project\database.sql`
- Click "Go"
- Wait for success message

#### Step 4: Verify Users
```sql
SELECT email, role FROM users;
```
Should show:
- admin@dairy-x.com | admin
- demo@dairy-x.com | user

#### Step 5: Test Login
- Username: `admin` or `admin@dairy-x.com`
- Password: `admin123`

---

### **Method 3: Use SQL File (Automated)**

I've created a SQL file for you:

#### Step 1: Open phpMyAdmin
- Go to: http://localhost/phpmyadmin
- Select database: `dairy_ecommerce`

#### Step 2: Import Fix
- Click "Import" tab
- Choose file: `c:\xampp\htdocs\Project\fix_admin_password.sql`
- Click "Go"

#### Step 3: Test Login
- Username: `admin`
- Password: `admin123`

---

## 🧪 Verification Steps

### Check 1: Verify Database Update
```sql
SELECT email, role, 
       LEFT(password_hash, 20) as hash_preview 
FROM users 
WHERE role = 'admin';
```

Should return:
- Email: admin@dairy-x.com
- Role: admin
- Hash starts with: `$2y$10$e0MYzXyjpJS7...`

### Check 2: Test API Directly

Open browser and go to:
```
http://localhost/Project/api/auth.php?action=check
```

**Before login** should return:
```json
{
  "success": true,
  "authenticated": false
}
```

### Check 3: Test Admin Login API

Use a tool like Postman or browser console:

```javascript
fetch('http://localhost/Project/api/auth.php?action=admin_login', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    username: 'admin',
    password: 'admin123'
  })
})
.then(r => r.json())
.then(console.log);
```

Should return:
```json
{
  "success": true,
  "message": "Admin login successful",
  "user": {
    "id": 1,
    "fullname": "Admin User",
    "email": "admin@dairy-x.com",
    "role": "admin"
  }
}
```

---

## 🔍 Still Having Issues?

### Issue 1: "Admin not found"
**Cause**: Admin user doesn't exist in database

**Solution**:
```sql
INSERT INTO users (fullname, email, phone, password_hash, role) 
VALUES ('Admin User','admin@dairy-x.com','+91 9000000000', 
        '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
        'admin');
```

### Issue 2: "Database error"
**Cause**: Database connection failed

**Solution**:
1. Check MySQL is running in XAMPP
2. Verify `config.php` settings:
   ```php
   DB_HOST = 'localhost'
   DB_USER = 'root'
   DB_PASS = ''
   DB_NAME = 'dairy_ecommerce'
   ```

### Issue 3: Still shows "Unauthorized"
**Cause**: Session not being created properly

**Solution**:
1. Clear browser cache and cookies
2. Try in incognito/private mode
3. Check browser console for errors (F12)
4. Verify PHP sessions are enabled

### Issue 4: "Invalid credentials"
**Cause**: Password doesn't match hash

**Solution**:
Re-run the UPDATE query from Method 1 above

---

## 🎯 Default Credentials

After fix, these credentials will work:

### Admin Login:
- **Username**: `admin` OR `admin@dairy-x.com`
- **Password**: `admin123`

### Demo User Login:
- **Email**: `demo@dairy-x.com`
- **Password**: `password`

---

## 📝 What Was Fixed

1. **Updated database.sql** - Now includes correct password hash
2. **Updated auth.php** - Improved admin login logic
3. **Created fix_admin_password.sql** - Quick fix script
4. **Added username support** - Can login with 'admin' or email

---

## 🔐 Password Hash Explanation

The password hash `$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC` is:
- Algorithm: bcrypt
- Cost: 10
- Password: `admin123` (for admin) or `password` (for demo user)

This is a secure one-way hash. The actual passwords are NOT stored in the database.

---

## ✅ Success Indicators

You'll know it's fixed when:
1. ✅ Admin login redirects to dashboard (not back to login)
2. ✅ Dashboard shows statistics
3. ✅ You can see users, carts, and orders tabs
4. ✅ No "Unauthorized" alert appears
5. ✅ Browser console shows no errors

---

## 🚀 Quick Test Checklist

- [ ] MySQL running in XAMPP
- [ ] Database `dairy_ecommerce` exists
- [ ] Ran UPDATE query or re-imported database
- [ ] Cleared browser cache
- [ ] Tried login with: admin / admin123
- [ ] Successfully reached admin dashboard
- [ ] Can see statistics and data

---

## 📞 Need More Help?

If still having issues:

1. **Check Browser Console** (F12)
   - Look for red errors
   - Check Network tab for API responses

2. **Check PHP Error Log**
   - Location: `C:\xampp\apache\logs\error.log`
   - Look for recent errors

3. **Verify Database**
   ```sql
   -- Check if admin exists
   SELECT * FROM users WHERE role = 'admin';
   
   -- Check password hash
   SELECT email, LEFT(password_hash, 30) FROM users WHERE role = 'admin';
   ```

4. **Test Authentication API**
   - Open: http://localhost/Project/api/auth.php?action=check
   - Should return JSON (not error page)

---

**🎊 Your admin panel should now be accessible!**

**Credentials:**
- Username: `admin`
- Password: `admin123`

**Admin Panel URL:**
http://localhost/Project/admin-dashboard.html
