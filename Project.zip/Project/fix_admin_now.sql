-- ============================================
-- FIX: Create Admin User in dairy_ecommerce
-- ============================================
-- Run this SQL in phpMyAdmin to create admin user
-- ============================================

USE dairy_ecommerce;

-- Delete any existing admin user first
DELETE FROM users WHERE email = 'admin@dairy-x.com' OR role = 'admin';

-- Create admin user with correct password hash
-- Username: admin OR admin@dairy-x.com
-- Password: admin123
INSERT INTO users (fullname, email, phone, password_hash, role, created_at) 
VALUES (
    'Admin User',
    'admin@dairy-x.com',
    '+91 9000000000',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'admin',
    NOW()
);

-- Verify admin was created successfully
SELECT 
    id,
    fullname,
    email,
    role,
    created_at,
    '✅ Admin created! Login with: admin / admin123' as status
FROM users 
WHERE role = 'admin';

-- Show all users in database
SELECT 
    id,
    fullname,
    email,
    role,
    created_at
FROM users
ORDER BY role DESC, id ASC;
