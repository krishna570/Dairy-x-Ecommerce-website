-- Fix Admin Password Issue
-- This script updates the admin password hash to match 'admin123'
-- and demo user password to match 'password'

USE dairy_ecommerce;

-- Update admin password hash (password: admin123)
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'admin@dairy-x.com' AND role = 'admin';

-- Update demo user password hash (password: password)
UPDATE users 
SET password_hash = '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC'
WHERE email = 'demo@dairy-x.com' AND role = 'user';

-- Verify the update
SELECT email, role, 
       CASE 
           WHEN email = 'admin@dairy-x.com' THEN 'Password: admin123'
           WHEN email = 'demo@dairy-x.com' THEN 'Password: password'
           ELSE 'Other user'
       END as credentials
FROM users 
WHERE email IN ('admin@dairy-x.com', 'demo@dairy-x.com');
