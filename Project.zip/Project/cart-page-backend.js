// Cart Page Backend Integration

const API_BASE = 'api';
let cart = [];
let currentUser = null;

// Check authentication on load
document.addEventListener('DOMContentLoaded', async function() {
    await checkAuthentication();
    if (currentUser) {
        await loadCartFromBackend();
    }
    displayCart();
});

// Check if user is authenticated
async function checkAuthentication() {
    try {
        const response = await fetch(`${API_BASE}/auth.php?action=check`);
        const data = await response.json();
        
        if (data.success && data.authenticated) {
            currentUser = data.user;
        } else {
            currentUser = null;
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        currentUser = null;
    }
}

// Load cart from backend
async function loadCartFromBackend() {
    try {
        const response = await fetch(`${API_BASE}/cart.php?action=get`);
        const data = await response.json();
        
        if (data.success) {
            cart = data.items;
        }
    } catch (error) {
        console.error('Failed to load cart:', error);
    }
}

// Display cart
function displayCart() {
    const cartContent = document.getElementById('cartContent');
    
    if (!currentUser) {
        cartContent.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-user-lock"></i>
                <h2>Please login to view your cart</h2>
                <a href="login.html">Login Now</a>
            </div>
        `;
        return;
    }
    
    if (cart.length === 0) {
        cartContent.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h2>Your cart is empty</h2>
                <p>Add some delicious dairy products to get started!</p>
                <a href="index.php">Start Shopping</a>
            </div>
        `;
        return;
    }

    let total = 0;
    let itemsHTML = '<div class="cart-items">';
    
    cart.forEach((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        itemsHTML += `
            <div class="cart-item">
                <div class="item-details">
                    <div class="item-name">${item.name}</div>
                    <div class="item-category">Dairy-X Product</div>
                    <div class="item-price">₹${item.price.toFixed(2)}</div>
                </div>
                
                <div class="item-quantity">
                    <button class="qty-btn" onclick="updateQuantity(${item.product_id}, ${item.quantity - 1})">-</button>
                    <span class="qty-value">${item.quantity}</span>
                    <button class="qty-btn" onclick="updateQuantity(${item.product_id}, ${item.quantity + 1})">+</button>
                </div>
                
                <div class="item-actions">
                    <div style="font-size: 18px; font-weight: bold; margin-bottom: 10px;">
                        ₹${itemTotal.toFixed(2)}
                    </div>
                    <div>
                        <button class="buy-now-btn" onclick="buyNowFromCart(${index})">
                            <i class="fas fa-shopping-bag"></i> Buy Now
                        </button>
                    </div>
                    <div>
                        <button class="remove-btn" onclick="removeItem(${item.product_id})">
                            <i class="fas fa-trash"></i> Remove
                        </button>
                    </div>
                </div>
            </div>
        `;
    });
    
    itemsHTML += '</div>';
    
    const summaryHTML = `
        <div class="cart-summary">
            <h3 class="summary-title">Order Summary</h3>
            
            <div class="summary-row">
                <span>Subtotal (${cart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                <span>₹${total.toFixed(2)}</span>
            </div>
            
            <div class="summary-row">
                <span>Delivery Fee</span>
                <span>₹50.00</span>
            </div>
            
            <div class="summary-row">
                <span>Tax (5%)</span>
                <span>₹${(total * 0.05).toFixed(2)}</span>
            </div>
            
            <div class="summary-row total">
                <span>Total</span>
                <span>₹${(total + 50 + total * 0.05).toFixed(2)}</span>
            </div>
            
            <button class="checkout-btn" onclick="checkout()">
                <i class="fas fa-lock"></i> Proceed to Checkout
            </button>
            
            <div style="text-align: center; margin-top: 15px; color: #666; font-size: 14px;">
                <i class="fas fa-truck"></i> Cash on Delivery Available
            </div>
        </div>
    `;
    
    cartContent.innerHTML = `
        <div class="cart-content">
            ${itemsHTML}
            ${summaryHTML}
        </div>
    `;
}

// Update quantity
async function updateQuantity(productId, newQuantity) {
    if (newQuantity <= 0) {
        await removeItem(productId);
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/cart.php?action=update`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: newQuantity
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            await loadCartFromBackend();
            displayCart();
        } else {
            alert('Failed to update cart: ' + data.message);
        }
    } catch (error) {
        console.error('Update cart failed:', error);
        alert('Failed to update cart');
    }
}

// Remove item
async function removeItem(productId) {
    if (!confirm('Remove this item from cart?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/cart.php?action=delete`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                product_id: productId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            await loadCartFromBackend();
            displayCart();
        } else {
            alert('Failed to remove item: ' + data.message);
        }
    } catch (error) {
        console.error('Remove from cart failed:', error);
        alert('Failed to remove item');
    }
}

// Checkout
function checkout() {
    if (!currentUser) {
        alert('Please login to proceed with checkout');
        window.location.href = 'login.html';
        return;
    }
    
    window.location.href = 'checkout.html';
}

// Buy Now from Cart
function buyNowFromCart(index) {
    if (!currentUser) {
        alert('Please login to buy products');
        window.location.href = 'login.html';
        return;
    }
    
    const selectedItem = cart[index];
    sessionStorage.setItem('quickBuyItem', JSON.stringify(selectedItem));
    window.location.href = 'checkout.html';
}
