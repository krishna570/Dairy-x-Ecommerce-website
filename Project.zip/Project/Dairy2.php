<!DOCTYPE html>
<html lang="en">
<head>  
    <title>milk product</title>
    <link rel="shortcut icon" href="image/images (2).jfif" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <link rel="stylesheet"type="text/css"href="style.css"> 
    <meta name="description"content="this the page about milk product">
    <style type="text/css"> 
        h1 {
            
            
            text-align: center;
            box-sizing: border-box; 
            -webkit-text-fill-color: rgb(001);
            
        }
        nav{
            width:100%;
            height: 100px;
            color:black;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }
        a:active{
            background-color: rgb(184, 23, 225);
        }
        
        .dropbtn {
            background-color: #04AA6D;
            color: white;
            padding: 16px;
            font-size: 16px;
            border: none;
        }

        /* The container <div> - needed to position the dropdown content */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        /* Dropdown Content (Hidden by Default) */
        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f1f1f1;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        /* Links inside the dropdown */
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
        }

        /* Change color of dropdown links on hover */
        .dropdown-content a:hover {
            background-color: #ddd;
        }

        /* Show the dropdown menu on hover */
        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Change the background color of the dropdown button when the dropdown content is shown */
        .dropdown:hover .dropbtn {
            background-color: #3e8e41;
        }
       
        
        
    </style>
</head>
<body>
    <script src="script.js"></script>
    <h1>Dairy Product </h1>
 <div class="gallery">
    <img src="image/Merieux-NutriSciences-Dairy-Testing-and-services.jpg"alt="image">
    <img src="image/cheese-pepper-cheese-dairy-products-wallpaper-preview.jpg"alt="image">
    <img src="image/D1062_19_253_1200.jpg"alt="image">
    <img src="image/images.jfif"alt="image">
    <img src="image/IMG_6236.jpg"alt="image">
    <img src="image/360_F_517881863_jl9BYN7DN7qsEQHWSuXYoRkJFxUlzdVM.jpg"alt="image">
    <img src="image/istockphoto-2178111666-612x612.jpg"alt="image">
    <img src="image/milk-1489734923-2762748.jpeg"alt="image">
    <img src="image/Stick-butter.webp"alt="image">
    <img src="image/HD-wallpaper-dairy-products-milk-products-dairy-products-cheese.jpg"alt="image">
    <img src="image/istockphoto-910881428-612x612.jpg"alt="image">
    <img src="image/shutterstock_1232966839.webp"alt="image">
    <img src="image/download.jfif"alt="image">
    <img src="image/dairy-759.webp"alt="image">
    <img src="image/images (1).jfif"alt="image">
    <img src="image/GulabJamunWithMilkPowder-02.jpg"alt="image">
    <img src="image/shutterstock_1232966839-1024x742.avif" alt="image">
 </div> 
 <header>
    <nav>
        <div class="logo">
             Dairy-X
         </div>
         <div class="product">
            <a href="#home">🏚 Home</a>
            <div class="dropdown">
                <button class="dropbtn">🛍 Product</button>
                <div class="dropdown-content">
                    <a href="#Sweet">SWEET</a>
                    <a href="#Milk">MILK PRODUCT</a>
                    <a href="#Cream">Cream</a>
                </div>
            </div>
<a href="#contact">☎ Contact</a>
<a href="cart.html">🛒Cart (<span id="cartCount">0</span>)</a>
<a href="#buynow">🛍️Buy now</a>
 </div> 

 
</div> 

         <div class="register" id="authButton">
           <a href="login.html" id="authLink">LOG IN</a>
           </div>
    
    </nav>
    
 



    

</header>
<section id="Sweet" class="section-s1">
  <h2>Sweet Products</h2>
  <p>Sweet products are available</p>

  <div class="pro-container">
   <?php





while
{ ?>
  <!-- Product 1 -->
    <div class="pro">
    <?php 
    echo "<img src='$array[2]'>";
     echo "<div class='pr'>"; ?>
        <span>Dairy-X</span>
      <?php  echo "<h5>'$array[0]'</h5>"; ?>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div> 
      <?php   echo "<h4>'$array[1]'</h4>";  ?>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>
<?php    }  ?>



    <!-- Product 2 -->
    <div class="pro">
      <img src="Sweet/Milk-Product-Ghee-Instagram-Post-4.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Milk Mysore Pak</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 3 -->
    <div class="pro">
      <img src="Sweet/indian-sweets-with-milk-caramel-custard.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Jelly</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$5</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 4 -->
    <div class="pro">
      <img src="Sweet/sweetmilk.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Milk Cream</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$3</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 5 -->
    <div class="pro">
      <img src="Sweet/Rabri07.JPG">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Rabri</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$6</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 6 -->
    <div class="pro">
      <img src="Sweet/malai-sandwich.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Malai Sandwich</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!--product 7-->
    <div class="pro">
      <img src="Sweet/Dry-Gulab-Jamun-26359-pixahive.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>GulabJamun</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

        <!--product 8 -->
    <div class="pro">
      <img src="Sweet/Mango-Kalakand-Cake-1-500x500.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Kalakand</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

        <!--product 9-->
    <div class="pro">
      <img src="Sweet/kardant-sweet-1548313634-4654916.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Karadant</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>
    
        <!--product 10-->
    <div class="pro">
      <img src="Sweet/thabdi-barfi_kamdar_sweet_28dda75f-23d8-4c09-bbc5-7e7152b13d3e.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Barfi</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

        <!--product 11-->
    <div class="pro">
      <img src="Sweet/Cham-Cham-585x366.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Cham-cham</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

      <!--product 12 -->
    <div class="pro">
      <img src="Sweet/indian-sweet-food-badam-barfi-260nw-617397095.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Badam-barfi</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star-half-alt"></i>
        </div>
        <h4>$8</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

</div>
</section>

  <section id="Milk" class="section-s1">
  <h2>Milk-products </h2>
  <p>Milk products are available</p>

  <div class="pro-container">
    <!-- Product 1 -->
    <div class="pro">
      <img src="Milk/Homemade-white-makhan-02-500x375.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>White-makhan</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$2</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 2 -->
    <div class="pro">
      <img src="Milk/Salted-or-Unsalted-Butter-Which-Should-I-Use-When.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Butter</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    <!-- Product 3 -->
    <div class="pro">
      <img src="Milk/images.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Malai Panner</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

        <!-- Product 4 -->
    <div class="pro">
      <img src="Milk/Homemade-Ricotta_-14.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Ritcotta chease</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>


        <!-- Product 5 -->
    <div class="pro">
      <img src="Milk/mozzarella-pizza-recipe-instructions-120348.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Mozzarella chease</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

           <!-- Product 6-->
    <div class="pro">
      <img src="Milk/Homemade-cream-cheese-Thumbnail-scaled.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Cream chease</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

            <!-- Product 7-->
    <div class="pro">
      <img src="Milk/q11GhVAT.jpeg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Yogurt</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

    
            <!-- Product 8-->
    <div class="pro">
      <img src="Milk/Milk.avif">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Fresh Milk</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>

<div class="pro">
      <img src="Milk/image-asset.webp">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>Formented milk</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$4</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>


    </div>
    </section>
    
      <section id="Cream" class="section-s1">
  <h2>Cream-products </h2>
  <p>Cream products are available</p>

  <div class="pro-container">
    <!-- Product 1 -->
    <div class="pro">
      <img src="Milk/Homemade-white-makhan-02-500x375.jpg">
      <div class="pr">
        <span>Dairy-X</span>
        <h5>White-makhan</h5>
        <div class="star">
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
          <i class="fas fa-star"></i>
        </div>
        <h4>$2</h4>
        <button class="buy-btn">🛒 Add to Cart</button>
        <button class="buy-btn">🛍️ Buy Now</button>
      </div>
    </div>
    </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="section-s1">
        <h2>📞 Contact Us</h2>
        <p>Get in touch with Dairy-X for fresh dairy products delivery</p>
        
        <div class="contact-container">
            <div class="contact-info">
                <div class="info-item">
                    <h3>📍 Address</h3>
                    <p>Jawaharlal Nehru Engineering College<br>MGM University, Aurangabad<br>Maharashtra, India</p>
                </div>
                
                <div class="info-item">
                    <h3>📧 Email</h3>
                    <p>info@dairy-x.com<br>support@dairy-x.com</p>
                </div>
                
                <div class="info-item">
                    <h3>📱 Phone</h3>
                    <p>+91 1234567890<br>+91 0987654321</p>
                </div>
                
                <div class="info-item">
                    <h3>🕒 Working Hours</h3>
                    <p>Monday - Saturday: 8:00 AM - 8:00 PM<br>Sunday: 9:00 AM - 6:00 PM</p>
                </div>
            </div>
            
            <div class="contact-form">
                <h3>Send us a message</h3>
                <form id="contactForm" onsubmit="handleContactForm(event)">
                    <input type="text" placeholder="Your Name" required>
                    <input type="email" placeholder="Your Email" required>
                    <input type="tel" placeholder="Your Phone">
                    <textarea placeholder="Your Message" rows="5" required></textarea>
                    <button type="submit" class="buy-btn">Send Message</button>
                </form>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h3>About Dairy-X</h3>
                <p>Your trusted source for fresh, quality dairy products delivered to your doorstep.</p>
            </div>
            
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#Sweet">Sweet Products</a></li>
                    <li><a href="#Milk">Milk Products</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Follow Us</h3>
                <div class="social-links">
                    <a href="#">Facebook</a>
                    <a href="#">Instagram</a>
                    <a href="#">Twitter</a>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Dairy-X | Developed by Krishna Vinayak Solanke | FYMCA Project</p>
        </div>
    </footer>

    <script>
        function handleContactForm(event) {
            event.preventDefault();
            alert('Thank you for contacting us! We will get back to you soon.');
            event.target.reset();
        }

        // Check login status and update button on load
        window.addEventListener('load', function() {
            updateAuthButton();
        });
    </script>

    
</body>
</html>
