# 🔐 Admin User Setup Guide for Dairy-X

## ✅ Your Admin Credentials
```
Email/Username: admin@dairy-x.com OR admin
Password: admin123
```

---

## 🚀 Method 1: Import the Full Database (RECOMMENDED)

### Step 1: Open phpMyAdmin
1. Make sure XAMPP is running (Apache + MySQL)
2. Open browser and go to: `http://localhost/phpmyadmin`

### Step 2: Delete Old Database (if exists)
1. Click on `dairy_ecommerce` database in left sidebar (if it exists)
2. Click **"Operations"** tab at the top
3. Scroll down and click **"Drop the database"**
4. Confirm deletion

### Step 3: Import Database
1. Click **"Import"** tab at the top
2. Click **"Choose File"** button
3. Browse to: `C:\xampp\htdocs\Project\database.sql`
4. Click **"Go"** button at the bottom
5. Wait for success message: "Import has been successfully finished"

### Step 4: Verify Admin User
1. Click on `dairy_ecommerce` database in left sidebar
2. Click on `users` table
3. You should see **Admin User** with email `admin@dairy-x.com`

### Step 5: Login
1. Go to: `http://localhost/Project/index.php`
2. Click **Admin Login** button
3. Enter:
   - **Username**: `admin` OR `admin@dairy-x.com`
   - **Password**: `admin123`
4. Click **Login**

---

## 🔧 Method 2: Create Admin Only (Keep Existing Data)

If you already have products/orders and don't want to lose them, use this method:

### Step 1: Open phpMyAdmin
1. Go to: `http://localhost/phpmyadmin`
2. Click on `dairy_ecommerce` database

### Step 2: Run SQL Query
1. Click **"SQL"** tab at the top
2. Copy and paste this code:

```sql
-- Delete old admin if exists
DELETE FROM users WHERE email = 'admin@dairy-x.com';

-- Create new admin user
INSERT INTO users (fullname, email, phone, password_hash, role, created_at) 
VALUES (
    'Admin User',
    'admin@dairy-x.com',
    '+91 9000000000',
    '$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC',
    'admin',
    NOW()
);

-- Verify admin was created
SELECT id, fullname, email, role, 'Password: admin123' as password 
FROM users 
WHERE role = 'admin';
```

3. Click **"Go"** button
4. You should see success message and admin details displayed

### Step 3: Login
1. Go to: `http://localhost/Project/index.php`
2. Click **Admin Login**
3. Login with: `admin` / `admin123`

---

## 🛠️ Method 3: Use Auto-Fix Script

### Step 1: Run Check Script
1. Open browser and go to: `http://localhost/Project/check_admin.php`
2. This will automatically:
   - Check if admin exists
   - Create admin if missing
   - Fix password if incorrect

### Step 2: Follow Instructions
The script will show you:
- ✅ Admin status
- 🔑 Login credentials
- 🔗 Direct link to admin login

---

## 🐛 Troubleshooting

### Problem: "Unauthorized" error when logging in

**Solution 1**: Update password hash
1. Go to phpMyAdmin → `dairy_ecommerce` → `users` table
2. Click **Edit** (pencil icon) for admin user
3. In `password_hash` field, paste: 
   ```
   $2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC
   ```
4. Click **Go** to save
5. Try logging in again with `admin123`

**Solution 2**: Run the check script
- Go to: `http://localhost/Project/check_admin.php`
- It will auto-fix the password

### Problem: Admin user doesn't exist

**Solution**: Import `create_admin_user.sql`
1. phpMyAdmin → `dairy_ecommerce` database
2. Click **Import** tab
3. Choose file: `C:\xampp\htdocs\Project\create_admin_user.sql`
4. Click **Go**

### Problem: Database doesn't exist

**Solution**: Import full database
1. Follow **Method 1** above
2. Import `database.sql` file

---

## 📋 Quick Checklist

Before you can login to admin panel, make sure:

- [ ] XAMPP is running (Apache + MySQL both green)
- [ ] Database `dairy_ecommerce` exists
- [ ] Table `users` exists in the database
- [ ] Admin user exists in `users` table with:
  - Email: `admin@dairy-x.com`
  - Role: `admin`
  - Password hash: `$2y$10$e0MYzXyjpJS7Pd0RVvHwHe6/bF0ZqZP1vMPqPJbGXKJwLSu6CkLyC`

---

## 🎯 Verification Query

To check if admin exists, run this in phpMyAdmin SQL tab:

```sql
SELECT id, fullname, email, role, created_at 
FROM users 
WHERE role = 'admin';
```

**Expected Result:**
```
id  | fullname   | email                  | role  | created_at
----|------------|------------------------|-------|-------------------
1   | Admin User | admin@dairy-x.com      | admin | 2025-10-15 ...
```

If you see this, your admin is ready! ✅

---

## 🔗 Useful Links

- **phpMyAdmin**: http://localhost/phpmyadmin
- **Website**: http://localhost/Project/index.php
- **Admin Check Script**: http://localhost/Project/check_admin.php
- **Fix Everything**: http://localhost/Project/fix-everything.html

---

## 💡 Final Notes

1. **Default Password**: The password `admin123` is for development only. Change it in production!
2. **Password Hash**: All passwords in the database are securely hashed using bcrypt
3. **Login**: You can use either `admin` or `admin@dairy-x.com` as username
4. **Role**: Admin role gives you access to admin panel with full control

---

**Need Help?** 
- Check the auto-fix script: `http://localhost/Project/check_admin.php`
- Review: `fix-everything.html` for all solutions in one place
