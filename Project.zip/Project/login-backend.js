// Login Page Backend Integration

const API_BASE = 'api';

function switchLoginType(type) {
    const userBtn = document.getElementById('userLoginBtn');
    const adminBtn = document.getElementById('adminLoginBtn');
    const userForm = document.getElementById('userLoginForm');
    const adminForm = document.getElementById('adminLoginForm');
    const signupLink = document.getElementById('signupLink');

    if (type === 'user') {
        userBtn.classList.add('active');
        adminBtn.classList.remove('active');
        userForm.classList.add('active');
        adminForm.classList.remove('active');
        signupLink.style.display = 'block';
    } else {
        adminBtn.classList.add('active');
        userBtn.classList.remove('active');
        adminForm.classList.add('active');
        userForm.classList.remove('active');
        signupLink.style.display = 'none';
    }
}

async function handleUserLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('userEmail').value;
    const password = document.getElementById('userPassword').value;

    try {
        const response = await fetch(`${API_BASE}/auth.php?action=login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                password: password
            })
        });

        const data = await response.json();

        if (data.success) {
            alert('Login successful! Welcome back, ' + data.user.fullname);
            window.location.href = 'index.php';
        } else {
            alert('Login failed: ' + data.message);
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Login failed. Please try again.');
    }
}

async function handleAdminLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('adminUsername').value;
    const password = document.getElementById('adminPassword').value;

    try {
        const response = await fetch(`${API_BASE}/auth.php?action=admin_login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (data.success) {
            alert('Admin login successful! Redirecting to dashboard...');
            window.location.href = 'admin-dashboard.html';
        } else {
            alert('Admin login failed: ' + data.message);
        }
    } catch (error) {
        console.error('Admin login error:', error);
        alert('Admin login failed. Please try again.');
    }
}
